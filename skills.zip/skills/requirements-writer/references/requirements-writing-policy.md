# Requirements Writing Policy

## 汎用性

このSkillは任意のプロジェクトで使えるようにする。
特定ドメイン、特定クラウド、特定フレームワーク、特定業務の前提を埋め込まない。

## 要件定義の役割

docs/requirements.md は、後続のSkillやCodexが対象リポジトリの目的を理解するための基準文書である。

docs/requirements.md には、以下を明確に書く。

- 何を作るか
- なぜ作るか
- 誰が使うか
- 何ができればよいか
- 何をやらないか
- どんな制約があるか
- 何が未決か
- 次に何をするか

## 要件と設計を分ける

このSkillでは要件定義を作る。
ディレクトリ構造、AGENTS.md、Agent Team、実装コードは作らない。

ただし、ユーザーが明示したディレクトリ構造案がある場合は docs/requirements.md の「ディレクトリ構造案」に記載してよい。

## Skill内AgentTeamとプロジェクト内AgentTeamの違い

requirements-writer Skill 内の agents/ は、要件定義を進めるための内部補助ロールである。

これは対象プロジェクトの開発用AgentTeamではない。

禁止事項:
- Skill内 agents/ を対象リポジトリにコピーしない
- requirements-writer 実行時に .codex/agents/ を作らない
- agent-router.md を作らない
- プロジェクト固有のAgent Teamを作らない

プロジェクト固有のAgent Teamは、後続の requirements-to-agent-team Skill が docs/requirements.md、docs/structure.md、階層別AGENTS.md を読んで生成する。

## 未決事項の扱い

不明点を無理に決めない。
判断できないことは「未決事項」に残す。

ただし、ユーザーが暫定作成を求めている場合は、作業を止めずに暫定要件として整理する。

## 質問方針

質問は必要最小限にする。
原則として1回の応答で1〜3問までにする。
多くても5問までにする。

質問は対話形式で進める。
ユーザーの回答を受け取ったら、現在の整理を短く示し、次に必要な質問だけを出す。

質問するより暫定整理した方が有益な場合は、未決事項を残して docs/requirements.md を作る。

## 対話形式の方針

このSkillは、ユーザーとの対話を通じて要件定義を段階的に作る。

重要:
- 一問一答または少数質問で進める
- 回答を都度要件に反映する
- 回答済み、未回答、未決事項を分ける
- 選択肢を出してユーザーが答えやすくする
- 対話ログをそのまま貼らず、要件として整理して書く
- ユーザーが暫定作成を求めたら、追加質問で止めずに作成する

## 完了条件

- docs/requirements.md が作成または更新されている
- 作りたいものが明確になっている
- 利用者が明確になっている
- 主要機能が整理されている
- やらないことが書かれている
- 完了条件が書かれている
- 未決事項が書かれている
- 次のステップとして setup-project-structure が書かれている
- tasks/todo.md に確認事項が書かれている
- Skill内AgentTeamを対象リポジトリにコピーしていない
- .codex/agents/ を作っていない
- agent-router.md を作っていない
