---
name: requirements-writer
description: 任意のリポジトリで、ユーザーのアイデア、メモ、既存README、既存ドキュメントをもとに docs/requirements.md を作成・更新する汎用スキル。Skill内に要件定義補助用の内部AgentTeamを持つ。ユーザーが「要件定義を作って」「requirements.mdを作って」「アイデアを要件にして」「この内容を要件定義に整理して」「後続Skillに渡せる要件にして」と依頼した場合に使う。
---

# Requirements Writer

## このSkillの目的

このSkillは、任意のリポジトリでユーザーのアイデア、メモ、README、既存ドキュメント、会話内容をもとに docs/requirements.md を作成・更新するための汎用Skillである。

このSkillは対象リポジトリに以下を生成・更新する。

- docs/requirements.md
- tasks/todo.md

このSkillは以下を作らない。

- docs/structure.md
- AGENTS.md
- 階層別AGENTS.md
- .codex/agents/
- agent-router.md
- プロジェクト固有Agent Team
- 実装コード

docs/requirements.md 作成後は、後続の setup-project-structure Skill を実行する。

## 補助ファイル

作業時は必要に応じて以下を参照する。

- references/requirements-writing-policy.md
- assets/requirements.md.template
- assets/interview-questions.md
- assets/requirements-checklist.md

## 重要原則

- 特定プロジェクト固有の前提をこのSkillに埋め込まない
- ユーザーの目的を勝手に拡大しない
- 曖昧な点は未決事項として残す
- 要件不足があっても止まりすぎない
- 断定できないことは「暫定」または「未決」と明記する
- 要件定義と設計を混ぜすぎない
- 技術選定が未確定なら候補または未決事項として扱う
- 実装ディレクトリ構造はこのSkillでは決めない
- ディレクトリ構造案がユーザーから出ている場合のみ docs/requirements.md に記載する
- 既存の docs/requirements.md がある場合は勝手に全面上書きしない
- 既存ファイルを変更する場合は必要に応じて .bak を作る
- .env、秘密情報、認証情報は読まない・表示しない・変更しない
- 個人情報・秘密情報・認証情報を docs/requirements.md に書かない
- 後続の setup-project-structure が読みやすい粒度で整理する
- Skill内 agents/ は対象リポジトリにコピーしない
- requirements-writer 実行時に対象リポジトリへ .codex/agents/ を作らない
- requirements-writer 実行時に対象リポジトリへ agent-router.md を作らない

## Skill内AgentTeam

このSkillには、要件定義を進めるための内部AgentTeamを持つ。

このAgentTeamは、対象リポジトリに生成するAgentTeamではない。
対象リポジトリの .codex/agents/ とは無関係である。
プロジェクト固有のAgent Teamは、後続の requirements-to-agent-team Skill が担当する。

Skill内AgentTeamの定義は以下に置く。

- agents/requirements-facilitator.md
- agents/user-scenario-analyst.md
- agents/functional-requirements-analyst.md
- agents/non-functional-requirements-analyst.md
- agents/scope-risk-reviewer.md
- agents/requirements-editor.md

このAgentTeamは、docs/requirements.md を作成・更新するための思考補助として使う。
対象リポジトリへコピーしてはいけない。

### 各Agentの役割

#### requirements-facilitator

要件定義全体の進行役。
ユーザーの曖昧な依頼を整理し、必要最小限の質問を決める。

担当:
- 要件定義の進行
- 対話方針の決定
- 質問方針の決定
- 情報不足の整理
- 暫定判断の明記
- docs/requirements.md 全体の一貫性確認

#### user-scenario-analyst

利用者、利用シーン、業務フローを整理する役割。

担当:
- 想定利用者の整理
- 利用シーンの整理
- 利用者ごとの目的整理
- 管理者と一般利用者の分離
- 権限や操作範囲の整理

#### functional-requirements-analyst

主要機能を整理する役割。

担当:
- 必須機能の抽出
- 任意機能の抽出
- 管理者向け機能の整理
- 利用者向け機能の整理
- 入力、出力、外部連携の整理
- 機能の優先度整理

#### non-functional-requirements-analyst

非機能要件を整理する役割。

担当:
- セキュリティ
- 性能
- 可用性
- 運用
- 監査ログ
- 保守性
- コスト
- 制約条件

#### scope-risk-reviewer

スコープ、やらないこと、リスク、未決事項を整理する役割。

担当:
- スコープの明確化
- やらないことの明確化
- 仕様膨張の抑制
- リスク整理
- 未決事項整理
- 完了条件の確認

#### requirements-editor

最終的に docs/requirements.md に整える編集役。

担当:
- 章立ての統一
- 表現の明確化
- 後続Skillが読みやすい粒度への調整
- 重複の整理
- 未決事項の明記
- 次のステップの記載

### Skill内AgentTeamの使い方

要件定義を作るときは、必要に応じて以下の順で内部AgentTeamの観点を使う。

1. requirements-facilitator で全体方針を決める
2. user-scenario-analyst で利用者と利用シーンを整理する
3. functional-requirements-analyst で機能要件を整理する
4. non-functional-requirements-analyst で非機能要件を整理する
5. scope-risk-reviewer でスコープ、リスク、未決事項を整理する
6. requirements-editor で docs/requirements.md に統合する

ただし、これは思考補助であり、必ず全Agentを機械的に使う必要はない。
小さい要件では必要な観点だけ使う。

## 対話形式で要件定義を進める方針

このSkillは、最初から完成版の docs/requirements.md を一方的に作るだけではなく、ユーザーとの対話を通じて要件定義を段階的に育てる。

### 対話の基本方針

- 一度に大量の質問をしない
- 原則として1回の応答で1〜3問までにする
- ユーザーが答えやすい順番で聞く
- 抽象的な質問だけでなく、選択肢や例を出す
- ユーザーの回答を毎回要約し、要件定義へ反映する
- 反映先の章を明示する
- 未回答の内容は「未決事項」として管理する
- ユーザーが「わからない」「おまかせ」「暫定で」と答えた場合は、暫定判断として記録する
- ユーザーが「これで作って」「一旦作って」と言ったら、現時点の情報で docs/requirements.md を作成・更新する

### 対話の進め方

対話は以下の順番で進める。

1. 作りたいものを確認する
2. 背景・目的を確認する
3. 利用者を確認する
4. 主要機能を確認する
5. 管理者向け機能と利用者向け機能を確認する
6. 入力と出力を確認する
7. 外部連携を確認する
8. 認証・認可を確認する
9. 非機能要件を確認する
10. 技術方針と運用方針を確認する
11. やらないことを確認する
12. 完了条件を確認する
13. 未決事項を整理する
14. docs/requirements.md に反映する

ただし、すべてを必ず質問する必要はない。
小さいプロジェクトでは必要な項目だけ確認する。

### 最初の質問

ユーザーから十分な情報がない場合、最初は以下のように聞く。

```txt
まず要件定義の土台を作ります。次の3つだけ教えてください。

1. 何を作りたいですか？
2. 誰が使いますか？
3. 何ができれば完成ですか？
```

### 追加質問の出し方

追加質問は、回答内容に応じて必要最小限にする。

例:

```txt
ここまでの内容は以下として反映します。

- 作りたいもの: ...
- 利用者: ...
- 完了条件: ...

次に、機能を整理したいので2点だけ教えてください。

1. 利用者が必ずできる必要がある操作は何ですか？
2. 管理者だけができる操作はありますか？
```

### 選択肢を出す質問

ユーザーが迷いそうな項目は選択肢を出す。

例:

```txt
認証はどれに近いですか？

A. ログインなし
B. リンクを知っている人だけ使える
C. 管理者ログインだけ必要
D. 一般ユーザーと管理者でログインを分ける
E. 未定
```

### 回答を反映するルール

ユーザーの回答を受け取ったら、以下を行う。

- 回答内容を短く要約する
- docs/requirements.md のどの章に反映するか判断する
- 既存の内容と矛盾があれば確認する
- 不明点は未決事項に追加する
- 必要なら次の質問を1〜3問だけ出す

### 対話中の一時整理

対話の途中では、必要に応じて以下の形式で現在の整理を表示する。

```txt
現在の整理:

## 作りたいもの
...

## 利用者
...

## 主要機能
...

## 未決事項
...
```

### docs/requirements.md を作成するタイミング

以下のいずれかの場合に docs/requirements.md を作成・更新する。

- ユーザーが「作って」「保存して」「requirements.mdにして」と言った
- 最小限の要件が揃った
- これ以上質問しても進みにくい
- ユーザーが暫定作成を望んだ
- 既存 docs/requirements.md を更新する依頼だった

最小限の要件とは以下である。

- 作りたいもの
- 利用者
- 主要機能
- やらないこと、または未決事項
- 完了条件、または暫定完了条件

### 対話ログの扱い

対話ログそのものを長々と docs/requirements.md に貼り付けない。
ユーザー回答を要件として整理して書く。

必要な判断理由は簡潔に書く。
雑談、一時的な迷い、秘密情報は書かない。

## 実行手順

### Step 1: 対象リポジトリの確認

- 現在の作業ディレクトリを確認する
- Gitルートがあれば対象リポジトリのルートとして扱う
- Gitルートがなければ現在のディレクトリを対象ルートとして扱う
- 既存の主要ファイルを確認する
- README.md があれば読む
- docs/ 配下に既存ドキュメントがあれば確認する
- docs/requirements.md があれば読む
- .env や秘密情報ファイルは読まない

確認対象の例:
- README.md
- docs/*.md
- package.json
- pyproject.toml
- go.mod
- Cargo.toml
- composer.json
- terraform files
- docker-compose.yml
- その他、プロジェクトの性質を推測できる設定ファイル

ただし、設定ファイルは要件理解の補助として見るだけで、実装変更はしない。

### Step 2: ユーザー入力の整理

ユーザーが直接渡した内容、既存README、既存ドキュメントから以下を抽出する。

- 作りたいもの
- 背景・目的
- 解決したい課題
- 想定利用者
- 利用シーン
- 主要機能
- 管理者向け機能
- 利用者向け機能
- 入力データ
- 出力データ
- 外部連携
- 認証・認可
- 非機能要件
- 技術方針
- 運用方針
- 制約
- やらないこと
- 未決事項

抽出できない項目は空欄にせず、必要に応じて以下のように記載する。

- 未定
- 要確認
- 現時点では未決
- ユーザー確認が必要

### Step 3: Skill内AgentTeamの観点で整理する

必要に応じて、Skill内 agents/ の定義を読み、以下の観点で要件を整理する。

- requirements-facilitator: 全体目的、質問方針、未決事項
- user-scenario-analyst: 利用者、利用シーン、権限、操作範囲
- functional-requirements-analyst: 機能、入力、出力、外部連携
- non-functional-requirements-analyst: 非機能、認証、運用、制約
- scope-risk-reviewer: やらないこと、リスク、完了条件
- requirements-editor: docs/requirements.md への統合

注意:
- このAgentTeamは思考補助である
- 対象リポジトリに agents/ をコピーしない
- 対象リポジトリに .codex/agents/ を作らない
- 対象リポジトリに agent-router.md を作らない

### Step 4: 対話で不足要件を確認する

要件が不足している場合は、対話形式で必要最小限の質問をする。

一度に質問しすぎない。
原則として1回の応答で1〜3問までにする。
多くても5問までにする。

対話では以下を繰り返す。

1. 現在わかっている要件を短く要約する
2. docs/requirements.md のどの章に反映するか整理する
3. 不足している重要項目を1〜3問だけ質問する
4. ユーザーの回答を受けて要件を更新する
5. 未回答の内容は未決事項に残す

優先して確認する質問:
1. 何を作りたいか
2. 誰が使うか
3. 何ができれば完成か
4. 必須機能は何か
5. やらないことは何か
6. 技術や運用上の制約はあるか

ユーザーが「とりあえず作って」「暫定で作って」「これで作って」と依頼している場合は、追加質問で止めずに暫定版を作る。

質問せずに進める場合は、未確認事項を docs/requirements.md の「未決事項」に残す。

### Step 5: docs/requirements.md の生成・更新

docs/requirements.md を作成または更新する。

既存の docs/requirements.md を大きく書き換える場合は、必要に応じて docs/requirements.md.bak を作る。

docs/requirements.md には必ず以下の章を含める。

# 要件定義

## 作りたいもの

## 背景・目的

## 解決したい課題

## 利用者

## 利用シーン

## 主要機能

## 管理者向け機能

## 利用者向け機能

## 入力

## 出力

## 外部連携

## 認証・認可

## 非機能要件

## 技術方針

## 運用方針

## ディレクトリ構造案

## やらないこと

## 制約

## 完了条件

## 未決事項

## 次のステップ

「次のステップ」には必ず以下を書く。

次に setup-project-structure Skill を実行し、この要件定義をもとにディレクトリ構造、docs/structure.md、AGENTS.md、tasksファイルを生成する。

### Step 6: 要件の粒度を整える

docs/requirements.md は、後続の setup-project-structure が構造を判断しやすい粒度にする。

良い書き方:
- 機能単位で箇条書きにする
- 利用者別に分ける
- 管理者機能と利用者機能を分ける
- やらないことを明確にする
- 未決事項を残す
- 完了条件を書く

悪い書き方:
- 抽象的な一文だけで終わる
- 実装コードを書く
- ディレクトリ構造を勝手に細かく決めすぎる
- 特定技術を根拠なく決める
- ユーザーが言っていない機能を勝手に追加する
- 秘密情報を書く
- .codex/agents/ や agent-router.md を作る

### Step 7: tasks/todo.md の作成・更新

tasks/todo.md を作成または更新する。

既存の tasks/todo.md を大きく書き換える場合は、必要に応じて tasks/todo.md.bak を作る。

含める内容:
- 要件定義で未決になっていること
- ユーザー確認が必要なこと
- 技術選定で保留したこと
- 完了条件の確認
- 次に setup-project-structure を実行すること

tasks/todo.md の形式:

# TODO

## 要件確認

## 未決事項

## 技術確認

## 次のステップ

- setup-project-structure を実行する

### Step 8: 完了報告

作業後、以下を報告する。

- 作成ファイル一覧
- 更新ファイル一覧
- docs/requirements.md に整理した主要要件
- Skill内AgentTeamのどの観点を使ったか
- 未決事項
- ユーザー確認が必要な点
- 対象リポジトリに .codex/agents/ を作っていないこと
- 対象リポジトリに agent-router.md を作っていないこと
- 次に実行すべきSkill: setup-project-structure
- 次にCodexへ投げるプロンプト例
