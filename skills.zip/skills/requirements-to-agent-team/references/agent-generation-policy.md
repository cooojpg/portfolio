# Agent Generation Policy

## 目的

このポリシーは、構造決定済みの任意のリポジトリから、要件と構造に合ったAgent Teamを一貫した方針で生成するための補助ルールである。

## 前提入力

最低限、以下を前提にする。

- `docs/requirements.md`
- `docs/structure.md`
- ルート `AGENTS.md`
- 主要ディレクトリ上の `AGENTS.md`

`docs/structure.md` がなければ生成を止め、先に `requirements-to-structure` を案内する。

## 読み取りポリシー

- リポジトリ全体を無差別に読まず、`docs/structure.md` に書かれた主要パスから読む
- 主要パスごとに、そのパス自身と上位パスの `AGENTS.md` を読む
- `.env`、秘密情報、認証情報、ローカル設定の中身は読まない
- 要件そのものは勝手に書き換えない

## Core Agent の固定方針

必ず以下のCore Agentを基準にする。

- `coordinator`
- `agent-router`
- `planner`
- `implementer`
- `reviewer`
- `tester`
- `security`
- `devops`
- `docs-writer`

Core Agentはプロジェクト固有の人格設定にせず、責務、確認観点、呼び出し条件、出力形式で定義する。

## Specialist Agent の選定方針

Specialist Agent は、独立した主要責務を持つ領域にだけ作る。

作成を強く検討する条件:

- `docs/structure.md` で明確な責務が定義されている
- `docs/requirements.md` にその領域へ紐づく要件束がある
- 階層別 `AGENTS.md` に独自ルールがある
- 重要なデータ、外部連携、権限、運用、テスト、デプロイ、ドキュメントに深く関わる

原則として作らない条件:

- 単なる `components`
- 単なる `utils`
- 単なる `types`
- 単なる `constants`
- 他のSpecialist Agentと責務がほぼ同じ

迷う場合の判断:

- その領域単独でレビュー観点や制約を説明したくなるなら作る
- 単独Agentにすると責務の重複が増えるなら作らない
- まず少なめに作り、不足が明確になったら増やす

## 命名方針

- 生成先: `.codex/agents/generated/`
- ファイル名: `<path>-specialist.md`
- `/` は `-` に置換する
- 例: `app/api` -> `app-api-specialist.md`

## agent-router 方針

`agent-router.md` は必ず作る。

必須ルール:

- 作業開始時は最初に `agent-router.md` を参照させる
- `agent-router.md` は必要な場合に使うべき subagent の組み合わせも示す
- 対象パスに対応するSpecialist Agentがあれば必ず参照させる
- 複数領域にまたがる変更は `coordinator`
- セキュリティ関連は `security`
- デプロイ、環境、運用関連は `devops`
- ドキュメント更新は `docs-writer`
- 実装後は `reviewer` と `tester` を通す
- 迷った場合は `coordinator`

## ルート AGENTS.md 方針

ルート `AGENTS.md` の `## Agent Team` 節には、少なくとも以下を明記する。

- 作業開始時は最初に `.codex/agents/agent-router.md` を参照する
- `agent-router` の判断に従って必要な subagent を spawn する
- 対象パスに対応するSpecialist Agentがある場合は、その参照を先に行う
- 複数領域にまたがる変更は `coordinator` を起点にする
- 実装後は `reviewer` と `tester` の観点を通す

## 既存ファイル更新方針

更新対象:

- `.codex/agents/*.md`
- `.codex/agents/generated/*.md`
- ルート `AGENTS.md`
- `docs/structure.md`
- `tasks/todo.md`
- `tasks/lessons.md`

更新ルール:

- 既存Agentファイルを全面更新する場合は `.bak` を作る
- 小さな節追加で済むファイルは、対象節だけ更新する
- ルート `AGENTS.md` は `## Agent Team` 節を追加または更新する
- `docs/structure.md` は `## Agent対応表` を追加または更新する
- `tasks/` は既存メモを保持したまま追記または対象節更新にとどめる

## tasks 更新方針

`tasks/todo.md` には以下を残す。

- Agent Team生成後に確認すべきこと
- 未生成のSpecialist Agentがある場合の理由
- 要件不足によりAgent化しなかった領域
- `agent-router.md` の確認事項

`tasks/lessons.md` には以下を残す。

- Agent Team運用メモ
- Agentを増やしすぎないこと
- Specialist Agentは主要責務に限定すること
- プロジェクト固有の判断は要件と構造に基づくこと
- 役割が重複するAgentを作らないこと

## 完了前チェック

- Core Agent が全てそろっているか
- Specialist Agent の数が過剰でないか
- `agent-router.md` にタスク種別表とパス対応表があるか
- ルート `AGENTS.md` に Agent Team 節があり、最初に `agent-router` を参照する規則と subagent spawn 規則があるか
- `docs/structure.md` に Agent対応表があるか
- `tasks/todo.md` と `tasks/lessons.md` に未決事項と運用メモがあるか
- 未生成領域の理由を説明できるか
