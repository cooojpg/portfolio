---
name: requirements-to-agent-team
description: 構造決定済みの任意のリポジトリで docs/requirements.md、docs/structure.md、階層別AGENTS.mdを読み、要件と構造に合ったCore Agent Team、agent-router、Specialist Agentを生成する汎用スキル。ユーザーが「Agent Teamを作って」「構造に合わせてAgentを定義して」「Specialist Agentを作って」「タスクごとのAgent呼び出しを定義して」と依頼した場合に使う。
---

# Requirements to Agent Team

## このSkillの目的

このSkillは、構造決定済みの任意のリポジトリで docs/requirements.md、docs/structure.md、階層別AGENTS.md を読み、要件と構造に合ったAgent Teamを生成するための汎用Skillである。

このSkillは対象リポジトリに以下を生成・更新する。

- .codex/agents/coordinator.md
- .codex/agents/agent-router.md
- .codex/agents/planner.md
- .codex/agents/implementer.md
- .codex/agents/reviewer.md
- .codex/agents/tester.md
- .codex/agents/security.md
- .codex/agents/devops.md
- .codex/agents/docs-writer.md
- .codex/agents/generated/*-specialist.md
- .codex/agents/README.md
- ルートAGENTS.md の Agent Team セクション
- docs/structure.md の Agent対応表
- tasks/todo.md
- tasks/lessons.md

このSkillはディレクトリ構造を決定しない。
ディレクトリ構造が未決定の場合は、先に requirements-to-structure Skill を実行するよう案内する。

このSkillを使うときは、まず [references/agent-generation-policy.md](references/agent-generation-policy.md) を読み、その後に `assets/` 配下のテンプレートを使って対象リポジトリへ反映する。

## 重要原則

- 特定プロジェクト固有の前提をこのSkillに埋め込まない
- Agent定義は docs/requirements.md、docs/structure.md、階層別AGENTS.md から導く
- Core Agentは汎用的にする
- Specialist Agentは主要責務を持つ領域にだけ作る
- Specialist Agentを生成しすぎない
- 単なる components、utils、types、constants には原則作らない
- 各Specialist Agentには、対応する要件、対象パス、参照すべきAGENTS.mdを書く
- .env、秘密情報、認証情報は読まない・表示しない・変更しない
- 既存Agentを上書きする必要がある場合は、原則として .bak を作るか差分案を出す
- Agent定義は「作業者の人格」ではなく「確認観点・責務・呼び出し条件」として書く
- Agent同士の役割が重複しすぎないようにする
- agent-router.md は必ず生成し、タスクごとの参照Agentを明確にする
- ルートAGENTS.md には、最初に必ず agent-router を参照することを明記する
- ルートAGENTS.md には、必要な場合は適切な subagent を spawn することを明記する
- ルートAGENTS.md と docs/structure.md は必要な節だけを更新し、既存の本文を壊さない
- tasks/ 以下は既存メモを消さずに更新する

## テンプレート利用方針

以下のテンプレートを起点にする。

- `assets/coordinator.md.template` -> `.codex/agents/coordinator.md`
- `assets/agent-router.md.template` -> `.codex/agents/agent-router.md`
- `assets/planner.md.template` -> `.codex/agents/planner.md`
- `assets/implementer.md.template` -> `.codex/agents/implementer.md`
- `assets/reviewer.md.template` -> `.codex/agents/reviewer.md`
- `assets/tester.md.template` -> `.codex/agents/tester.md`
- `assets/security.md.template` -> `.codex/agents/security.md`
- `assets/devops.md.template` -> `.codex/agents/devops.md`
- `assets/docs-writer.md.template` -> `.codex/agents/docs-writer.md`
- `assets/specialist.md.template` -> `.codex/agents/generated/*-specialist.md`
- `assets/agents-index.md.template` -> `.codex/agents/README.md`

プレースホルダーは対象リポジトリの要件と構造で埋める。
テンプレートの文面をそのまま複製せず、対象パスと要件に合わせて具体化する。

## 実行手順

### Step 1: 前提確認

以下を確認する。

- docs/requirements.md が存在すること
- docs/structure.md が存在すること
- ルートAGENTS.md が存在すること
- 主要ディレクトリのAGENTS.md が存在すること

docs/structure.md が存在しない場合は停止し、先に requirements-to-structure を実行するよう案内する。

主要ディレクトリのAGENTS.mdが不足している場合は、停止しすぎず tasks/todo.md に不足として記録する。
ただし、Agent生成は docs/requirements.md と docs/structure.md をもとに可能な範囲で進める。

主要ディレクトリは docs/structure.md に出てくる責務の重いパスから決める。
該当パス自身のAGENTS.mdだけでなく、上位パスにあるAGENTS.mdも読む。

### Step 2: 要件と構造の読み込み

以下を読む。

- docs/requirements.md
- docs/structure.md
- ルートAGENTS.md
- 重要ディレクトリごとのAGENTS.md

読み取り観点:

- プロジェクト目的
- 主要機能
- 主要ディレクトリ
- 各ディレクトリの責務
- 各ディレクトリに紐づく要件
- セキュリティ・権限・外部公開に関係する領域
- テスト・検証に関係する領域
- デプロイ・環境・運用に関係する領域
- ドキュメントに関係する領域
- データ・永続化に関係する領域
- 外部連携に関係する領域
- 複数領域をまたぐ作業が発生しそうな部分

読み取り結果は、後続のCore Agent定義、Specialist Agent定義、Agent対応表で再利用できるよう短く整理する。

### Step 3: Core Agent Team の生成

対象リポジトリに .codex/agents/ を作り、以下を生成する。

- .codex/agents/coordinator.md
- .codex/agents/agent-router.md
- .codex/agents/planner.md
- .codex/agents/implementer.md
- .codex/agents/reviewer.md
- .codex/agents/tester.md
- .codex/agents/security.md
- .codex/agents/devops.md
- .codex/agents/docs-writer.md
- .codex/agents/README.md

各Core Agentには以下を含める。

- 役割
- 責務
- 呼び出し条件
- 確認観点
- 出力形式
- 他Agentとの連携方針
- やってはいけないこと

Core Agent概要:

coordinator:
- 複合タスクの司令塔
- 要件、構造、対象AGENTS.md、agent-routerを確認する
- 必要Agentを選定する
- 作業計画を作る
- 実装後に reviewer / tester / docs-writer へつなぐ

agent-router:
- タスク内容から参照すべきAgentを決める
- Core AgentとGenerated Specialist Agentを選ぶ
- 判断表を持つ
- 最初に参照する入口になる
- 必要なら使うべきsubagentの組み合わせを示す
- 対象パスに対応するSpecialist Agentがある場合は必ず参照させる
- 迷った場合はcoordinatorを使う

planner:
- 要件整理
- 設計
- 作業分解
- 実装順序
- リスク整理

implementer:
- 実装担当
- plannerの計画に沿う
- 必要最小限の変更
- 既存構成に合わせる
- スコープを勝手に広げない

reviewer:
- 変更レビュー
- 過剰実装チェック
- 仕様逸脱チェック
- 既存構成との整合性チェック
- 下位AGENTS.md違反チェック

tester:
- テスト観点
- 既存テストの確認
- 変更内容に応じた検証方法の提案
- 実行できなかった検証の明記

security:
- 秘密情報
- 認証
- 認可
- 外部公開
- 権限境界
- 危険な設定や意図しない公開の検出
- ただし過剰なセキュリティ設計を押し付けない

devops:
- CI/CD
- デプロイ
- 環境設定
- インフラ構成
- ローカル開発環境
- 再現性
- 運用しやすさ

docs-writer:
- README
- requirements
- structure
- 設計メモ
- 運用手順
- 実装とドキュメントのズレ修正

### Step 4: Specialist Agent の生成

docs/requirements.md、docs/structure.md、階層別AGENTS.md から、重要領域ごとのSpecialist Agentを生成する。

生成先:

.codex/agents/generated/

生成判断:

- docs/structure.md に記載された主要ディレクトリを優先する
- 重要な責務を持つトップレベルディレクトリには原則作る
- 重要なネスト階層がある場合は末端または中間階層にも作る
- 生成しすぎない
- 単なる components、utils、types、constants には原則作らない
- 独自責務、重要なデータ、外部連携、権限、運用、テスト、デプロイ、ドキュメントなどに関わる領域を優先する
- 既に同等のSpecialist Agentがある場合は重複生成しない

命名:

- <path>-specialist.md
- / は - に置換する
- 例: app/api -> app-api-specialist.md

Specialist Agent形式:

# {AGENT_NAME}

## 役割

{TARGET_PATH} 配下の専門Agent。

## 対象範囲

- `{TARGET_PATH}/`

## 関連要件

docs/requirements.md、docs/structure.md、対象ディレクトリのAGENTS.mdから抽出した、この領域に関係する要件を書く。

## 参照すべきルール

- ルートAGENTS.md
- 対象パス上のAGENTS.md
- docs/requirements.md
- docs/structure.md

## 主な責務

- この領域の要件を守る
- 関連するAGENTS.mdを確認する
- 既存構成に合わせる
- 変更影響を明記する
- 必要に応じて planner / reviewer / tester / security / devops / docs-writer と連携する

## 呼び出し条件

- {TARGET_PATH}/ 配下の変更
- この領域に関する仕様変更
- この領域のバグ修正
- この領域のテスト追加
- この領域のドキュメント修正

## 確認観点

- 関連要件に沿っているか
- 対象ディレクトリの責務外の実装が混ざっていないか
- 上位AGENTS.mdと矛盾していないか
- 他領域への影響がある場合にcoordinatorへ戻しているか

## 注意事項

- 勝手に責務を広げない
- 他領域に影響する場合は coordinator に戻す
- 破壊的変更は事前に理由を書く

### Step 5: agent-router.md の生成

.codex/agents/agent-router.md には以下を含める。

- Core Agent一覧
- Generated Specialist Agent一覧
- タスク種別ごとの参照Agent
- 対象パスごとのSpecialist Agent対応表
- 最初に必ず agent-router を参照するルール
- 必要な場合に subagent を spawn するルール
- 迷った場合はcoordinatorを使うルール
- 実装後はreviewer/testerの観点で確認するルール
- セキュリティに関係する場合はsecurityを必ず参照するルール
- デプロイ・環境・運用に関係する場合はdevopsを必ず参照するルール
- ドキュメントに関係する場合はdocs-writerを参照するルール
- 複数領域にまたがる場合はcoordinatorを参照するルール
- 対象パスに対応するSpecialist Agentがあれば必ず参照するルール

タスク種別ごとの標準ルーティング:

| タスク種別 | 参照Agent |
|---|---|
| 要件整理 | planner, docs-writer |
| 設計変更 | coordinator, planner, reviewer |
| 小さな実装 | implementer, reviewer |
| 新機能追加 | coordinator, planner, implementer, reviewer, tester |
| バグ修正 | implementer, reviewer, tester |
| テスト追加 | tester, implementer, reviewer |
| セキュリティ関連 | security, reviewer |
| デプロイ・環境・運用 | devops, reviewer |
| ドキュメント更新 | docs-writer, reviewer |
| 複数領域変更 | coordinator |

### Step 6: .codex/agents/README.md の生成

.codex/agents/README.md を作成する。

含める内容:

- Agent Teamの目的
- Core Agent一覧
- Generated Specialist Agent一覧
- agent-router.mdの使い方
- どのタスクでどのAgentを参照するか
- Agentを増やすときの基準
- Agentを増やしすぎない方針

### Step 7: ルートAGENTS.md への反映

ルートAGENTS.md に Agent Team セクションを追加または更新する。

含める内容:

## Agent Team

このプロジェクトでは、作業開始時に最初に `.codex/agents/agent-router.md` を参照し、作業内容に応じて `.codex/agents/` のAgent定義を使い分ける。

### 基本方針

- 最初に必ず agent-router を参照する
- 複合タスクは coordinator
- Agent選定は agent-router
- 設計は planner
- 実装は implementer
- レビューは reviewer
- テストは tester
- セキュリティは security
- DevOps・環境・デプロイは devops
- ドキュメントは docs-writer
- ディレクトリ固有の作業は .codex/agents/generated/*-specialist.md

### 呼び出しルール

- 作業開始時は最初に agent-router を確認し、参照すべきAgentを決める
- agent-router が必要と判断する場合は subagent を spawn する
- 対象パスに対応するspecialistがあれば、そのspecialistを参照してから subagent を spawn する
- 単純な修正は該当領域のspecialist + implementer
- 複数領域にまたがる変更はcoordinator
- セキュリティに関わる変更はsecurityを参照する
- デプロイ・環境・運用に関わる変更はdevopsを参照する
- テスト・検証に関わる変更はtesterを参照する
- ドキュメントに関わる変更はdocs-writerを参照する
- 完了時はreviewerの観点で自己点検する

既存のAgent Teamセクションがある場合は、重複しないように更新する。

### Step 8: docs/structure.md への反映

docs/structure.md に Agent対応表を追加または更新する。

含める内容:

## Agent対応表

| ディレクトリ | 責務 | 関連要件 | Specialist Agent | 参照すべきCore Agent |
|---|---|---|---|---|

既存のAgent対応表がある場合は重複しないように更新する。

### Step 9: tasks ファイル更新

tasks/todo.md に以下を追加または更新する。

- Agent Team生成後に確認すべきこと
- 未生成のSpecialist Agentがある場合の理由
- 要件不足によりAgent化しなかった領域
- agent-router.md の確認

tasks/lessons.md に以下を追加または更新する。

- Agent Team運用メモ
- Agentを増やしすぎないこと
- Specialist Agentは主要責務に限定すること
- プロジェクト固有の判断は要件と構造に基づくこと
- 役割が重複するAgentを作らないこと

`tasks/` が structure 上の標準ディレクトリとして定義されている場合は必要ファイルを作成してよい。
`tasks/` 自体が未定義なら、新しい主要ディレクトリを勝手に増やさず、未決事項として報告する。

### Step 10: 完了報告

作業後、以下を報告する。

- 作成ファイル一覧
- 更新ファイル一覧
- 生成したCore Agents一覧
- 生成したSpecialist Agents一覧
- Specialist Agentを生成しなかった主要ディレクトリと理由
- agent-router.md の判断概要
- ルートAGENTS.mdに追記した内容
- docs/structure.mdに追記したAgent対応表
- tasks/todo.mdに追記した未決事項
- 手動で確認すべき点
- 次にCodexへ投げるプロンプト例

次にCodexへ投げるプロンプト例は、以下のような短い形でよい。

- `Use $requirements-to-agent-team to generate the Agent Team from docs/requirements.md and docs/structure.md.`
- `requirements-to-agent-team を使って、このリポジトリの Agent Team を作成してください。`
- `構造に合わせて Specialist Agent と agent-router を生成してください。`
