# Use This Team In Claude Code

Use this prompt as a starting point when you want Claude Code to operate with a generated AgentTeam:

```text
Use the AgentTeam configuration in <output-dir>.
Read team.yaml, the agent role files in agents/, and the workflow files in workflows/.
Execute the work using those roles and handoffs.
If you cannot spawn parallel agents, simulate the team sequentially while preserving role boundaries.
Document assumptions, keep work inside the requested scope, and ask before any destructive or production-affecting action.
```

Recommended additions:

- include the target repository or working directory
- name the final artifact you want produced
- state whether existing files may be updated, copied, or only read
