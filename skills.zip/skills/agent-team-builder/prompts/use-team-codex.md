# Use This Team In Codex

Use this prompt as a starting point when you want Codex to operate with a generated AgentTeam:

```text
Use the AgentTeam configuration in <output-dir>.
Read team.yaml, all files under agents/, and the files under workflows/ and prompts/.
Follow the documented handoffs and review gates.
If subagents are available, map them to the defined roles.
If subagents are not available, emulate the roles sequentially and keep the same artifact handoffs.
State assumptions before execution and do not perform destructive operations without explicit approval.
```

Recommended additions:

- specify the exact deliverable you want
- specify whether the run is planning-only or implementation-allowed
- specify any directories that must remain untouched
