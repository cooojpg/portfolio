# Generation Checklist

Run this checklist before finalizing a generated AgentTeam.

## Requirements Analyst check

- Purpose is explicit.
- Target tools are explicit.
- Output directory is explicit.
- Assumptions are listed.
- Existing-file handling is stated.

## Domain Researcher check

- Domain is identified correctly.
- Specialist agents are justified.
- Cloud / infra agents were not added by default.

## Agent Architect check

- Core and specialist agents are separated.
- Every agent has a clear mission.
- Non-goals are written for each agent.
- No major role overlaps remain.

## Workflow Designer check

- Execution order is explicit.
- Inputs and outputs are named.
- Review points are present.
- Rework conditions are present.

## Safety Reviewer check

- No destructive default actions.
- Overwrite behavior is explicit.
- Secrets are prohibited.
- Production changes are prohibited unless explicitly authorized.

## Output Formatter check

- Markdown is readable.
- YAML is valid and structured.
- File names are kebab-case.
- README explains usage.

## Quality Reviewer check

- The output is immediately usable.
- The generated files match the requested purpose.
- Specialist agents are not overused.
- Trigger phrases and aliases are documented in the skill.
