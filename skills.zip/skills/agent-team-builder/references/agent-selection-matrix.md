# Agent Selection Matrix

Use this matrix when deciding which `specialist_agents` to add.

## Rule

Start with the full `core_agents` set. Add specialists only when the user request creates clear role-specific work that generic agents should not absorb.

## Domain mapping

| Domain | Add these specialists when justified | Typical triggers | Avoid adding when |
| --- | --- | --- | --- |
| Software / Web | `frontend-engineer`, `backend-engineer`, `database-designer`, `devops-engineer`, `api-designer`, `ux-designer` | UI, API, DB schema, deployment, CI/CD, UX | the request is only high-level planning |
| Business | `business-analyst`, `operations-analyst`, `process-improvement-designer`, `automation-designer`, `kpi-designer` | process mapping, bottlenecks, automation, KPI design | the request is only technical delivery |
| Research | `research-analyst`, `source-reviewer`, `synthesis-writer`, `fact-checker` | research plans, source quality, synthesis, fact checking | the request does not require evidence gathering |
| AI / LLM | `ai-architect`, `prompt-engineer`, `rag-designer`, `evaluation-designer`, `llm-ops-reviewer` | prompts, retrieval, evals, model behavior, AI ops | the request is generic software with no AI system design |
| Security | `security-reviewer`, `threat-modeler`, `compliance-reviewer`, `privacy-reviewer` | threat review, compliance, privacy, trust boundaries | security is not a meaningful concern in the request |
| Data | `data-analyst`, `analytics-engineer`, `visualization-designer`, `data-quality-reviewer` | analysis pipelines, dashboards, data quality, metrics | there is no data pipeline or reporting need |
| Content / Docs | `technical-writer`, `editor`, `proposal-writer` | formal docs, proposals, manuals, editorial polish | documentation is only a small side effect |
| Cloud / Infra | `cloud-architect`, `network-reviewer`, `iam-reviewer`, `terraform-reviewer`, `sre-incident-investigator`, `observability-reviewer` | AWS, Azure, GCP, VPC, IAM, Terraform, Kubernetes, SRE, monitoring | the request does not explicitly concern infrastructure |

## Decision questions

Ask:

- Does this role own work that none of the core agents should absorb?
- Is the specialty central to the deliverable, not just incidental?
- Would omitting the specialist create a quality or safety gap?
- Can the responsibility be stated clearly in one sentence?

If the answer is not clearly yes, do not add the specialist.
