# agent-team-builder

`agent-team-builder` is a reusable Skill for creating domain-agnostic AgentTeam scaffolds that work in both Codex and Claude Code.

This build was created at:

- `C:\Users\kouki\Desktop\agent-team-builder`

Skill directories detected in this environment:

- Codex: `C:\Users\kouki\.codex\skills`
- Claude Code: `C:\Users\kouki\.claude\skills`

An existing Claude Code skill already exists at:

- `C:\Users\kouki\.claude\skills\agent-team-builder`

If you install this build there, back it up first or rename it before replacing it.

## What this skill does

Use this skill when you want an AI agent to create a reusable AgentTeam for a user-specified goal, domain, target tool, and output directory.

The skill is intentionally generic. It supports:

- software and web development
- business improvement
- requirements definition
- research and analysis
- documentation and proposal work
- testing and review structures
- data and analytics work
- AI / RAG / LLM application design
- security review
- cloud / infra design review as one optional specialist domain

It does not default to cloud or infrastructure specialists.

## Included files

- `SKILL.md`: the main operating instructions
- `agents/openai.yaml`: Codex UI metadata
- `templates/`: reusable output templates
- `workflows/`: default workflow, review workflow, and internal design flow
- `prompts/`: starter prompts for Codex and Claude Code
- `examples/`: domain-specific team definition examples
- `references/`: specialist selection and quality checklist guidance

## Trigger phrases

The skill is written to trigger on names and phrases such as:

- `agent-team-builder`
- `AgentTeam Builder`
- `エージェントチーム作成スキル`
- `エージェントチームを作るスキルズ`
- `AgentTeam作成Skill`
- `複雑なAgentTeam設定作成Skill`
- `指定ディレクトリにエージェントチームを作って`
- `この要件に合うAgentTeamを作って`
- `Codex/Claude Code用のAgentTeam設定を作って`

## Internal design model

The skill itself uses these internal viewpoints when generating an AgentTeam:

1. Requirements Analyst Agent
2. Domain Researcher Agent
3. Agent Architect Agent
4. Workflow Designer Agent
5. Safety Reviewer Agent
6. Output Formatter Agent
7. Quality Reviewer Agent

## Default generated output

When this skill is used to generate a team, it is designed to create a scaffold like:

```text
<output-dir>/
  README.md
  team.yaml
  agents/
    requirements-analyst.md
    domain-researcher.md
    solution-architect.md
    workflow-designer.md
    implementation-planner.md
    risk-reviewer.md
    quality-reviewer.md
    test-designer.md
    documentation-writer.md
    executive-summarizer.md
  workflows/
    default-workflow.md
    review-workflow.md
  templates/
    agent-template.md
    team-template.yaml
  prompts/
    use-team-codex.md
    use-team-claude-code.md
  examples/
    general-project-agent-team.yaml
    web-app-agent-team.yaml
    business-process-improvement-agent-team.yaml
    research-and-analysis-agent-team.yaml
    ai-llm-agent-team.yaml
    cloud-infra-agent-team.yaml
```

Specialist agent files are added only when justified by the request.

## Install in Codex

PowerShell example:

```powershell
Copy-Item -Recurse -Force `
  C:\Users\kouki\Desktop\agent-team-builder `
  C:\Users\kouki\.codex\skills\agent-team-builder
```

If `C:\Users\kouki\.codex\skills\agent-team-builder` already exists, back it up first:

```powershell
Rename-Item `
  C:\Users\kouki\.codex\skills\agent-team-builder `
  C:\Users\kouki\.codex\skills\agent-team-builder.bak
```

## Install in Claude Code

PowerShell example:

```powershell
Rename-Item `
  C:\Users\kouki\.claude\skills\agent-team-builder `
  C:\Users\kouki\.claude\skills\agent-team-builder.bak

Copy-Item -Recurse -Force `
  C:\Users\kouki\Desktop\agent-team-builder `
  C:\Users\kouki\.claude\skills\agent-team-builder
```

If you want to keep the existing Claude version, copy this build under a different folder name and update the `name:` in `SKILL.md` accordingly.

## Safety notes

- Do not include secrets in generated files.
- Do not encode production-changing commands by default.
- Do not silently overwrite existing output files.
- Add cloud and infrastructure specialists only when the request explicitly calls for them.
