# Internal AgentTeam

This file documents how `agent-team-builder` reasons internally while constructing an AgentTeam.

## Sequence

1. `requirements-analyst`
2. `domain-researcher`
3. `agent-architect`
4. `workflow-designer`
5. `safety-reviewer`
6. `output-formatter`
7. `quality-reviewer`

## Operating rule

Do not skip a role. Each role either:

- confirms the current draft, or
- sends it back with a concrete correction request

## Minimal artifact chain

- `requirements-brief.md`
- `domain-notes.md`
- `team-shape.md`
- `workflow-outline.md`
- `safety-notes.md`
- `formatted-output/`
- `quality-review.md`
