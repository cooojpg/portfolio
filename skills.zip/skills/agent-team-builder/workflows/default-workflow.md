# Default Workflow

Use this workflow when generating a new AgentTeam from a user request.

## Phase 1: Requirements framing

- Owner: `requirements-analyst`
- Inputs: user request, target directory, constraints
- Outputs: `requirements-brief.md`
- Exit rule: purpose, output directory, target tools, and constraints are explicit

## Phase 2: Domain mapping

- Owner: `domain-researcher`
- Inputs: `requirements-brief.md`
- Outputs: `domain-notes.md`
- Exit rule: domain-specific concerns and specialist candidates are identified

## Phase 3: Agent architecture

- Owner: `solution-architect`
- Inputs: `requirements-brief.md`, `domain-notes.md`
- Outputs: `solution-outline.md`, draft `team.yaml`
- Exit rule: core vs specialist agent split is justified

## Phase 4: Workflow design

- Owner: `workflow-designer`
- Inputs: `solution-outline.md`
- Outputs: `execution-plan.md`, `workflows/default-workflow.md`
- Exit rule: handoffs, rework conditions, and review points are explicit

## Phase 5: Delivery planning

- Owner: `implementation-planner`
- Inputs: `execution-plan.md`
- Outputs: `implementation-plan.md`
- Exit rule: work is split into concrete deliverables and file outputs

## Phase 6: Verification design

- Owner: `test-designer`
- Inputs: `implementation-plan.md`, draft `team.yaml`
- Outputs: `test-plan.md`
- Exit rule: verification scope covers both structure and intended use

## Phase 7: Safety and quality review

- Owners: `risk-reviewer`, `quality-reviewer`
- Inputs: all draft artifacts
- Outputs: `risk-register.md`, `quality-review.md`
- Exit rule: destructive behavior is ruled out and gaps are documented

## Phase 8: Documentation and summary

- Owners: `documentation-writer`, `executive-summarizer`
- Inputs: approved artifacts
- Outputs: `README.md`, final notes, executive summary
- Exit rule: the team can be used immediately by another agent

## Rework triggers

Loop back when:

- the request is ambiguous
- specialist agents were added without a clear reason
- responsibilities overlap
- the workflow has no review gate
- the output would overwrite existing files unsafely
