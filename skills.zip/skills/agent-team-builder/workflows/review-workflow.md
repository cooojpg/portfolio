# Review Workflow

Use this workflow after drafting an AgentTeam.

## Review 1: Scope and role fit

- Reviewer set: `requirements-analyst`, `solution-architect`, `quality-reviewer`
- Check:
  - the team matches the stated goal
  - the team is not overbuilt
  - each role has a clear boundary

## Review 2: Specialist justification

- Reviewer set: `domain-researcher`, `solution-architect`, `quality-reviewer`
- Check:
  - each specialist agent is explicitly justified
  - unnecessary specialists are removed
  - cloud / infra agents are present only when the request requires them

## Review 3: Workflow operability

- Reviewer set: `workflow-designer`, `implementation-planner`, `test-designer`
- Check:
  - handoffs are concrete
  - artifacts are named
  - the workflow can be executed in Codex and Claude Code without hidden assumptions

## Review 4: Safety

- Reviewer set: `risk-reviewer`
- Check:
  - destructive operations are forbidden by default
  - file overwrite policy is explicit
  - no secrets or production modifications are encoded
  - confirmation-requiring actions are documented

## Review 5: Output clarity

- Reviewer set: `documentation-writer`, `executive-summarizer`
- Check:
  - README explains how to use the team
  - prompts are tool-appropriate
  - YAML and Markdown are readable

## Approval rule

Approve the scaffold only when:

- requirements are covered
- no major role overlaps remain
- safety rules are explicit
- generated files are ready to use without extra interpretation
