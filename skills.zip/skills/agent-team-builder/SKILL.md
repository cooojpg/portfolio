---
name: agent-team-builder
description: Build reusable, domain-agnostic AgentTeam configurations for Codex and Claude Code from a user's goal, constraints, target tools, and output directory. Use when asked to create, design, scaffold, or generate an agent team, subagent team, multi-agent workflow, review pipeline, or role-separated delivery setup for software development, web apps, business improvement, requirements work, research, analysis, documentation, product planning, testing, operations, security, data, AI/LLM, or cloud/infra. Trigger especially on phrases such as "agent-team-builder", "AgentTeam Builder", "エージェントチーム作成スキル", "エージェントチームを作るスキルズ", "AgentTeam作成Skill", "複雑なAgentTeam設定作成Skill", "指定ディレクトリにエージェントチームを作って", "この要件に合うAgentTeamを作って", and "Codex/Claude Code用のAgentTeam設定を作って".
---

# agent-team-builder

## Aliases

- agent-team-builder
- AgentTeam Builder
- エージェントチーム作成スキル
- エージェントチームを作るスキルズ
- AgentTeam作成Skill
- 複雑なAgentTeam設定作成Skill
- 複雑なエージェントチーム設定作成Skill

## When to use this skill

Use this skill whenever the user wants a reusable AgentTeam or multi-agent configuration created for a specific purpose and output directory.

This skill must trigger for Japanese and English requests like:

- 「エージェントチームを作るスキルズを使って」
- 「AgentTeamを作るスキルを使って」
- 「エージェントTeam作成Skillを使って」
- 「AgentTeam Builderを使って」
- 「agent-team-builderを使って」
- 「指定ディレクトリにエージェントチームを作って」
- 「この要件に合うAgentTeamを作って」
- 「複雑なエージェントチーム設定を作って」
- 「Codex/Claude Code用のAgentTeam設定を作って」

Also trigger when the user asks for:

- an agent team
- a subagent team
- a multi-agent workflow
- agent role separation
- a review pipeline
- a handoff-oriented execution team
- a reusable Codex / Claude Code team scaffold

## Goal

Create a reusable, domain-agnostic AgentTeam scaffold that another Codex or Claude Code instance can use immediately.

Do not bias toward cloud, infrastructure, or any other single domain. Start from generic core agents. Add specialist agents only when the user's goal requires them.

## Read These Files

- Read [templates/agent-template.md](templates/agent-template.md) before writing `agents/*.md`.
- Read [templates/team-template.yaml](templates/team-template.yaml) before writing `team.yaml`.
- Read [references/agent-selection-matrix.md](references/agent-selection-matrix.md) when mapping domain needs to specialist agents.
- Read [references/generation-checklist.md](references/generation-checklist.md) before finalizing output.
- Reuse [examples/](examples/) as starting points when the user's domain matches them.

## Inputs To Capture

Collect the following from the request. If some items are missing, make a reasonable assumption and document it in the generated `README.md`.

- the purpose of the AgentTeam
- the target tool: Codex, Claude Code, or both
- the output directory
- the desired team granularity
- the required deliverables
- the domain or problem space
- safety constraints
- allowed operations and forbidden operations
- how to handle existing files
- whether specialist agents are explicitly requested

## Default Assumptions

Use these defaults only when the user does not specify otherwise:

- output directory: `./agent-team/`
- target tools: Codex and Claude Code
- domain: `general`
- language: Japanese primary, English-friendly wording where helpful
- overwrite policy: never overwrite silently; create backups when practical
- safety posture: no destructive operations, no secrets, no production changes

Use this default `core_agents` set:

- `requirements-analyst`
- `domain-researcher`
- `solution-architect`
- `workflow-designer`
- `implementation-planner`
- `risk-reviewer`
- `quality-reviewer`
- `test-designer`
- `documentation-writer`
- `executive-summarizer`

Do not add cloud or infrastructure specialists by default.

## Internal AgentTeam

Run this skill as an internal seven-agent review loop. Treat each role as a required checkpoint.

### 1. Requirements Analyst Agent

Clarify:

- what the AgentTeam is for
- which tool or tools it targets
- where files should be written
- how detailed the team should be
- which outputs must exist
- safety constraints
- allowed operations and forbidden operations
- how to treat existing files

### 2. Domain Researcher Agent

Clarify:

- which domain the request belongs to
- whether generic agents are enough
- which specialist agents are justified
- which domain-specific risks matter
- which specialist review perspectives are needed

### 3. Agent Architect Agent

Clarify:

- which agents are required
- how to split `core_agents` and `specialist_agents`
- each agent's responsibility boundary
- each agent's non-goals
- agent handoffs
- whether the team is too large or too small
- whether the roles are understandable in both Codex and Claude Code

### 4. Workflow Designer Agent

Clarify:

- execution order
- step inputs and outputs
- review timing
- rework conditions
- final deliverables
- whether the flow is easy to operate in Codex and Claude Code

### 5. Safety Reviewer Agent

Clarify:

- deletion and overwrite handling
- command execution safety
- secret handling
- production change prohibition
- destructive operation prohibition
- which actions require explicit confirmation
- impact on existing files

### 6. Output Formatter Agent

Clarify:

- Markdown readability
- YAML validity
- clear file names
- clear directory layout
- README completeness
- bilingual usability

### 7. Quality Reviewer Agent

Clarify:

- whether the team satisfies the request
- whether responsibilities overlap too much
- whether any agent is missing
- whether the workflow is practical
- whether output formats are explicit
- whether the scaffold is immediately usable
- whether the trigger phrases are covered

## Agent Selection Policy

Start from `core_agents`. Add `specialist_agents` only when the stated purpose requires them.

### Core agents

Always begin with:

- `requirements-analyst`
- `domain-researcher`
- `solution-architect`
- `workflow-designer`
- `implementation-planner`
- `risk-reviewer`
- `quality-reviewer`
- `test-designer`
- `documentation-writer`
- `executive-summarizer`

### Specialist agents by domain

Add only the needed specialists:

- Software / Web: `frontend-engineer`, `backend-engineer`, `database-designer`, `devops-engineer`, `api-designer`, `ux-designer`
- Cloud / Infra: `cloud-architect`, `network-reviewer`, `iam-reviewer`, `terraform-reviewer`, `sre-incident-investigator`, `observability-reviewer`
- Business: `business-analyst`, `operations-analyst`, `process-improvement-designer`, `automation-designer`, `kpi-designer`
- Research: `research-analyst`, `source-reviewer`, `synthesis-writer`, `fact-checker`
- AI / LLM: `ai-architect`, `prompt-engineer`, `rag-designer`, `evaluation-designer`, `llm-ops-reviewer`
- Security: `security-reviewer`, `threat-modeler`, `compliance-reviewer`, `privacy-reviewer`
- Data: `data-analyst`, `analytics-engineer`, `visualization-designer`, `data-quality-reviewer`
- Content / Docs: `technical-writer`, `editor`, `proposal-writer`

Add cloud and infrastructure specialists only if the request explicitly involves cloud, AWS, Azure, GCP, Terraform, infrastructure, networking, Kubernetes, DevOps, SRE, or similar concerns.

Whenever a specialist agent is added, document:

- why it was added
- what responsibility it owns
- what it does not own

## Generation Procedure

Follow this sequence:

1. Normalize the request into a brief with purpose, scope, constraints, output directory, and target tools.
2. Infer the domain from the request. If unclear, keep it `general`.
3. Choose the core agents.
4. Add only the justified specialist agents.
5. Define each agent with mission, responsibilities, non-goals, inputs, outputs, collaboration, and guardrails.
6. Define a default execution workflow and a review workflow.
7. Encode safety rules in both `team.yaml` and `README.md`.
8. Create Codex and Claude Code usage prompts.
9. Create the output scaffold shown below unless the user explicitly asks for a smaller scaffold.
10. Run the quality checklist in [references/generation-checklist.md](references/generation-checklist.md).

## Output Contract

Unless the user explicitly asks for a reduced scaffold, generate this structure in the requested output directory:

```text
<output-dir>/
  README.md
  team.yaml
  agents/
    requirements-analyst.md
    domain-researcher.md
    solution-architect.md
    workflow-designer.md
    implementation-planner.md
    risk-reviewer.md
    quality-reviewer.md
    test-designer.md
    documentation-writer.md
    executive-summarizer.md
    # plus only the specialist agent files that are justified
  workflows/
    default-workflow.md
    review-workflow.md
  templates/
    agent-template.md
    team-template.yaml
  prompts/
    use-team-codex.md
    use-team-claude-code.md
  examples/
    general-project-agent-team.yaml
    web-app-agent-team.yaml
    business-process-improvement-agent-team.yaml
    research-and-analysis-agent-team.yaml
    ai-llm-agent-team.yaml
    cloud-infra-agent-team.yaml
```

Write the generated `README.md` so it states:

- purpose
- assumptions
- target tools
- why specialist agents were added
- safety boundaries
- how to use the generated team

Write `team.yaml` so it clearly separates:

- `core_agents`
- `specialist_agents`
- workflow
- safety rules
- deliverables

## File Writing Rules

- Create the target directory if it does not exist.
- Do not delete existing files unless the user explicitly requests it.
- Do not overwrite existing files silently.
- Back up existing files when practical by appending `.bak` or writing into a timestamped backup directory.
- Keep writes inside the requested output directory.
- Do not include secrets, tokens, passwords, or private keys.
- Do not encode commands that modify production systems.

## Output Style

- Use Markdown and YAML as the primary formats.
- Keep file names in lowercase kebab-case.
- Write concise, reusable agent definitions.
- Keep prompts compatible with both Codex and Claude Code.
- Prefer bilingual-friendly wording when appropriate.

## Usage Examples

### Generic

> エージェントチームを作るスキルズを使って、要件定義から設計、実装計画、レビュー、テスト、ドキュメント作成までを分担するAgentTeamを `./agent-teams/product-development` に作ってください。

### Web app

> agent-team-builderを使って、Webアプリ開発用のAgentTeamを `./agent-teams/web-app` に作ってください。フロントエンド、バックエンド、DB、テスト、レビューを分担してください。

### Business process improvement

> エージェントチームを作るスキルズを使って、社内業務改善のためのAgentTeamを `./agent-teams/biz-improvement` に作ってください。現状分析、課題整理、改善案、自動化案、効果測定を分担してください。

### Research and analysis

> agent-team-builderを使って、調査・分析タスク用のAgentTeamを `./agent-teams/research` に作ってください。調査計画、情報収集、ソース評価、統合、要約を分担してください。

### AI / LLM

> AgentTeam Builderを使って、LLM/RAGアプリ開発のためのAgentTeamを `./agent-teams/llm-app` に作ってください。要件、アーキテクチャ、プロンプト設計、RAG設計、評価設計、運用観点を分担してください。

### Cloud / infra

> エージェントチームを作るスキルズを使って、クラウド設計レビュー用のAgentTeamを `./agent-teams/cloud-review` に作ってください。IAM、ネットワーク、Terraform、監視、試験観点を入れてください。
