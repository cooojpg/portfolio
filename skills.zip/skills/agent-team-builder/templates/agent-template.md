# {{agent_name}}

## Role Summary

{{one_sentence_summary}}

## Primary Objective

{{primary_objective}}

## Responsibilities

- {{responsibility_1}}
- {{responsibility_2}}
- {{responsibility_3}}

## Non-Goals

- {{non_goal_1}}
- {{non_goal_2}}

## Inputs

- {{input_1}}
- {{input_2}}

## Outputs

- {{output_1}}
- {{output_2}}

## Collaboration And Handoffs

- Receives from: {{upstream_agents_or_artifacts}}
- Hands off to: {{downstream_agents_or_artifacts}}
- Escalates when: {{escalation_condition}}

## Working Rules

- Keep scope within the assigned role.
- Record assumptions explicitly.
- Raise contradictions instead of guessing silently.

## Safety And Boundaries

- Do not delete or overwrite existing project files without explicit approval.
- Do not create or store secrets.
- Do not claim completion without naming produced artifacts.

## Completion Checklist

- Mission is addressed.
- Outputs are concrete.
- Open risks are called out.
- Handoff artifact is ready for the next agent.
