design notes

Claude Code 版からの変更点

Claude Code 版の構成:

- `~/.claude/skills`
- `CLAUDE.md`
- `.claude/hooks`
- `SessionStart / PostToolUse`
- 階層別 `SKILL.md`

Codex 版の構成:

- Codex が起動している環境の `.codex/skills`
  - Windows ネイティブ: `%USERPROFILE%\.codex\skills`
  - macOS / Linux / WSL: `$HOME/.codex/skills`
- `AGENTS.md`
- 階層別 `AGENTS.md`
- `docs/structure.md`
- ディレクトリ構造レビューと `AGENTS.md` 内容レビュー用の Codex AgentTeam

なぜ AGENTS.md を使うか

Codex は AGENTS.md をプロジェクト指示として読む。
そのため、Claude Code の Hook で SKILL.md を注入する設計ではなく、Codex の標準的な AGENTS.md 階層管理に寄せる。

なぜ SKILL.md を階層制約に使わないか

Codex の SKILL.md は再利用可能なワークフローを定義するためのもの。
プロジェクト・ディレクトリ固有の作業ルールは AGENTS.md に書く方が自然。

Windows ネイティブ向けの扱い

- Skill の説明では、WSL や Unix シェルを前提にしない
- コマンド例が必要なら、PowerShell 例を併記する
- パス説明は `%USERPROFILE%` と `$HOME` の両方を許容し、特定 OS の絶対パスを前提にしない
- ディレクトリ構造案は論理パスとして `/` 区切りで表現し、実際のファイル生成時に環境側のパス解決へ委ねる

team フローについて

Codex では、ディレクトリ構造レビューと `AGENTS.md` 内容レビューで AgentTeam を必ず使う。
このSkillでは、規模を問わず次の役割を使う。

- 構造アーキテクト
- ディレクトリ契約 / AGENTS.md 設計
- 実装レビュアー
- 保守レビュアー

小規模プロジェクトでも単独モードにはせず、同じ AgentTeam で進める。
