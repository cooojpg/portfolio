---
name: setup-project-structure
description: Codex 用のプロジェクト構造セットアップSkill。docs/requirements.md を読み、AgentTeam を必ず使ってディレクトリ構造と AGENTS.md 内容を検討し、承認後は AGENTS.md、階層別 AGENTS.md、docs/structure.md、基本ディレクトリまで実際に作成する。ユーザーが「プロジェクト構造作って」「ディレクトリ構造セットアップ」「枠組み作って」「init 後の構造を作って」「骨組み作成」「Codex用の土台を作って」「AGENTS.md 配置」「複数視点で構造設計」「レビュー付きで構造提案」のように依頼した時に使う。
---

# setup-project-structure

このSkillは、任意のプロジェクトに Codex 用の構造管理ルールを導入する。

作成するもの:
1. ルート `AGENTS.md`
2. `docs/structure.md`
3. 各機能ディレクトリの `AGENTS.md`
4. 必要なディレクトリ構造
5. 既存ファイルがある場合の上書き確認・退避

Claude Code 用の以下は作成しない:
- `CLAUDE.md`
- `.claude/hooks/`
- `.claude/settings.json`
- Claude Code 専用の Hook
- Claude Code 専用の AgentTeam ファイル

Codex では `AGENTS.md` がプロジェクト指示の中心になる。
ルートの `AGENTS.md` は広域ルール、下位ディレクトリの `AGENTS.md` はそのディレクトリ固有の制約を書く。
Skill の配置先は、Codex が起動している環境の `.codex/skills` である。
例:
- Windows ネイティブ: `%USERPROFILE%\.codex\skills`
- macOS / Linux / WSL: `$HOME/.codex/skills`

## AgentTeam 原則

このSkillでは、ディレクトリ構造と `AGENTS.md` 内容の検討に `AgentTeam` を必ず使う。
ここでいう `AgentTeam` は、Codex の subagents を役割分担して使う進め方を指す。

必須ルール:
- 小規模プロジェクトでも `solo` には落とさない
- `軽くやって` と言われても、AgentTeam 自体は省略しない
- `提案だけ` の依頼でも、提案内容の検討は AgentTeam で行う
- `作成して` 系の依頼では、AgentTeam の検討結果を使って承認後に実ファイル作成まで進む
- subagent が使えない状況では単独で代替せず、使えない旨を説明して停止する

## 実行モード判定

まず、今回の依頼が `提案だけ` なのか `作成まで実行` なのかを判定する。

### 提案だけで止める依頼

次の語が明示されている時は、AgentTeam で構造案と内容案を検討し、提案だけを返す。

- `提案して`
- `相談したい`
- `レビューして`
- `叩き台だけ`
- `構造案だけ`

### 作成まで実行する依頼

次の語が明示されている時は、AgentTeam で検討したうえで、承認後にそのターンで実際にファイルを作成する。

- `作って`
- `作成して`
- `生成して`
- `配置して`
- `セットアップして`
- `初期構造を作って`
- `AGENTS.md も作って`

重要:
- ユーザーが作成系の依頼をしているなら、承認後に `提案だけで終わらせない`。
- `docs/requirements.md` に構造案が明示され、競合も無い場合でも、まず AgentTeam で妥当性と `AGENTS.md` 内容を検討する。
- 既存ファイルの上書き判断が必要な時だけ止まる。

## 前提条件チェック

着手前に以下を確認する。

1. `docs/requirements.md` が存在し、中身が空でないか
   - 無い、または空の場合は停止し、次だけ案内する。
   - `docs/requirements.md に要件を記入してから、このSkillを呼び戻してください。`
2. 既存の `AGENTS.md`、`docs/structure.md`、機能ディレクトリがあるか
   - 上書き
   - `.bak.YYYYMMDD-HHMMSS` 退避
   - スキップ
   のどれで扱うかを確認する。
3. ルート `AGENTS.md` が無い場合
   - ユーザーが作成系の依頼をしていれば、このSkillで新規作成してよい。
   - 提案だけの依頼なら、必要になることだけを案内して停止してよい。

## Step 1: 要件読み込み

`docs/requirements.md` を全文読み込む。次の2パターンに対応する。

### パターンA: ディレクトリ構造案あり

`## ディレクトリ構造案` セクション配下に Markdown bullet list がある場合、その内容を構造候補として採用する。

例:

```markdown
## ディレクトリ構造案
- challenges
- infra
  - envs/shared
  - envs/event
  - modules
- scoring
```

インデントは2スペース単位を期待する。
タブ混在の場合は警告し、2スペースに正規化する。
ディレクトリ構造案の区切り文字は、OS に関係なく論理パスとして `/` を優先する。
Windows 由来の `\` が混じる場合は、`/` に正規化して扱う。

### パターンB: ディレクトリ構造案なし

自由記述から候補を抽出する。
この場合は、構造案を提示して承認を得る。

## Step 2: AgentTeam で構造と内容を検討

### Step 2-0: AgentTeam 起動

必ず次の 4 役を起動する。

1. 構造アーキテクト agent
2. ディレクトリ契約 / AGENTS.md 設計 agent
3. 実装レビュアー agent
4. 保守レビュアー agent

これらは並列に実行してよい。
AgentTeam が使えない場合は、単独で続行してはいけない。

### Step 2-a: 構造アーキテクト agent

観点:
- ディレクトリの責務分離
- 依存関係
- 拡張性
- Codex の `AGENTS.md` 階層設計

出力は次のYAMLのみ。

```yaml
primary:
  tree: |
    .
    ├── ...
  rationale: "1-3文"
alternative:
  tree: |
    .
    ├── ...
  rationale: "1-3文"
  when_to_choose: "代替案を選ぶ条件"
key_decisions:
  - decision: "判断項目名"
    options_considered: ["...", "..."]
    chosen: "..."
    why: "..."
```

### Step 2-b: ディレクトリ契約 / AGENTS.md 設計 agent

観点:
- ルート `AGENTS.md` に置くべき広域ルール
- 各ディレクトリ `AGENTS.md` に置くべき責務、境界、依存、近接ファイル、検証方針
- 親子階層でどうルールを分担するか
- 要件が薄い場所にどの暫定ルールを書くか

出力は次のYAMLのみ。

```yaml
root_agents:
  purpose: "1-2文"
  rules:
    - "ルール"
directory_agents:
  shared_rules:
    - "複数ディレクトリに共通するルール"
  per_directory:
    - path: "app"
      purpose: "1-2文"
      owns:
        - "このディレクトリで扱うもの"
      avoids:
        - "このディレクトリで扱わないもの"
      change_checks:
        - "変更時に一緒に確認するもの"
      validation:
        - "最小限の検証"
assumptions:
  - "要件不足時の暫定前提"
```

### Step 2-c: 実装レビュアー agent

観点:
- 作成スクリプトの安全性
- 既存ファイルの退避
- OS差分
- パス解決
- `.gitignore` との整合性
- `AGENTS.md` の階層配置

出力は次のYAMLのみ。

```yaml
proposals:
  - severity: high
    point: "指摘"
    rationale: "理由"
    suggestion: "改善案"
```

### Step 2-d: 保守レビュアー agent

観点:
- 6ヶ月後、1年後に破綻しないか
- 新メンバーが理解しやすいか
- `docs/structure.md` で説明しやすいか
- ディレクトリ移動やリファクタリングがしやすいか
- `AGENTS.md` の階層分担が自然か

出力は次のYAMLのみ。

```yaml
proposals:
  - severity: high
    point: "指摘"
    rationale: "理由"
    suggestion: "改善案"
```

### Step 2-e: 統合

main agent は 4 つの結果を統合し、次の形式でユーザーに提示する。

```markdown
## 構造案

### プライマリ案
...

### 代替案
...

## AGENTS.md 内容方針

### ルート AGENTS.md
- ...

### ディレクトリ別 AGENTS.md
- `app`: ...
- `infra`: ...

## レビューで上がった主要な懸念

| 重大度 | レビュアー | 指摘 | 改善案 |
|---|---|---|---|
| high | 実装 | ... | ... |
| med | 保守 | ... | ... |

## 確認事項
1. プライマリ案 / 代替案 / 修正版 のどれで進めますか
2. 修正したい懸念はありますか
3. 各ディレクトリに AGENTS.md を置く方針で良いですか
4. 既存 AGENTS.md の扱いはどうしますか
```

重要:
- 提案だけの依頼なら、ここで止める。
- 作成系の依頼なら、ユーザーの承認が返ったターンで必ず Step 3 に進む。
- AgentTeam の結果が揃わないうちは、構造や `AGENTS.md` の内容を確定してはいけない。

## Step 3: ファイル生成

承認後、以下を生成する。

- `AGENTS.md`
- `docs/structure.md`
- 各機能ディレクトリ
- 各機能ディレクトリの `AGENTS.md`
- ネスト構造がある場合は、必要な中間ディレクトリの `AGENTS.md`

生成後、各 `AGENTS.md` の内容レビューは常に AgentTeam で行う。
少なくとも次の 2 役は再度起動する。

1. AGENTS.md 内容レビュアー agent
2. 保守レビュアー agent

レビュー観点:
- 責務の具体性
- 編集境界
- 依存方向
- 近接ファイル参照
- 検証方針
- 親子 `AGENTS.md` 間の分担

生成ルール:

- 既存ファイルは勝手に上書きしない
- 上書き承認済みなら実施
- 退避指定なら `.bak.YYYYMMDD-HHMMSS` を付けて退避
- 改行コードは LF
- シェルやコマンド例は、Codex が動いている環境に合わせる
- Windows ネイティブでは PowerShell で違和感のない説明を優先する
- パスは実行環境のホームディレクトリを解決して扱う
  - Windows ネイティブ: `%USERPROFILE%`
  - macOS / Linux / WSL: `$HOME`
- `~` を文字列のままファイルパスに使わない
- `/home/...` のような特定 OS 固定パスを説明文に埋め込まない
- `.gitignore` に未記載なら、次の追記を提案する

```gitignore
# Codex local settings
.codex/
```

ただし、プロジェクト共有したい `AGENTS.md` や `docs/structure.md` は除外しない。

### 生成内容の最低要件

各 `AGENTS.md` は、プレースホルダのまま残してはいけない。
次のような文言は禁止。

- `記述してください`
- `TODO`
- `あとで埋める`
- 空見出しだけの状態

各 `AGENTS.md` には最低でも次を含める。

1. そのディレクトリの責務
2. 何をこのディレクトリで扱い、何を扱わないか
3. 依存方向や編集境界
4. 変更時に一緒に見るべき近接ファイル
5. 最低限の検証方針

内容は `docs/requirements.md` と AgentTeam の結果から具体化する。
要件に十分な情報が無い場合でも、空欄にせず、保守的なデフォルトルールを具体文で書く。
その場合は、必要なら `暫定` や `Assumption` と明記する。

### 生成方法

- AgentTeam の統合結果をもとに、各 `AGENTS.md` をプロジェクト固有の内容へ具体化する
- 補助スクリプトはディレクトリ作成や初期配置に使ってよい
- ただし、スクリプト出力をそのまま納品してはいけない
- 生成後に必ず AgentTeam に各 `AGENTS.md` をレビューさせ、弱い文や汎用文を具体化する

## Step 4: 検証

生成後、最低でも次を行う。

1. 作成ファイル一覧を確認する
2. `AGENTS.md` と `docs/structure.md` の場所を確認する
3. 各 `AGENTS.md` にプレースホルダが残っていないか確認する
4. AgentTeam で決めた責務や境界が、実際のファイル内容に反映されているか確認する
5. 可能なら最小限の構文チェックや関連検証を行う

確認コマンド例:

```sh
find . -name AGENTS.md -o -path ./docs/structure.md
```

```powershell
Get-ChildItem -Recurse -Filter AGENTS.md | Select-Object -ExpandProperty FullName
Get-Item .\docs\structure.md
```

## Step 5: 完了報告

次を報告する。

- 作成ファイル一覧
- 退避したファイル一覧
- 採用した構造
- `AGENTS.md` に入れた重要ルール
- AgentTeam で採用した主要判断
- 残った暫定事項や要件不足
- 次アクション

次アクション例:
- 各 `AGENTS.md` にプロジェクト固有の検証コマンドを追記
- `docs/requirements.md` を更新しながら構造を育てる
- 実装着手前に、変更対象ディレクトリの `AGENTS.md` を確認する

## このSkill自身のルール

- 承認前にファイルを作らない
- 既存ファイルを勝手に上書きしない
- Claude Code 専用ファイルは作らない
- Codex 用のプロジェクト指示は `AGENTS.md` に集約する
- AgentTeam の役割は固定する
- subagent 出力は YAML に限定する
- YAML が破れた場合は 1 回だけ再要求する
- それでも破れた場合は単独で進めず、ユーザーに知らせて停止する
- 作成系の依頼では、承認後に提案だけで止まらない
- 生成する `AGENTS.md` にプレースホルダを残さない
