#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import shutil
from pathlib import Path, PurePosixPath


def timestamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d-%H%M%S")


def backup_path(path: Path) -> Path:
    return path.with_name(path.name + f".bak.{timestamp()}")


def safe_write(path: Path, content: str, mode: str) -> None:
    if path.exists():
        if mode == "skip":
            print(f"SKIP: {path}")
            return
        if mode == "backup":
            dst = backup_path(path)
            shutil.move(str(path), str(dst))
            print(f"BACKUP: {path} -> {dst}")
        elif mode == "overwrite":
            print(f"OVERWRITE: {path}")
        else:
            raise ValueError(f"unknown mode: {mode}")

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8", newline="\n")
    print(f"WRITE: {path}")


def load_template(skill_dir: Path, name: str) -> str:
    return (skill_dir / "templates" / name).read_text(encoding="utf-8")


def normalize_relative_dir(raw: str) -> Path:
    normalized = raw.strip().replace("\\", "/")
    pure = PurePosixPath(normalized)
    if str(pure) in {"", "."}:
        raise ValueError("empty directory path is not allowed")
    if pure.is_absolute() or ".." in pure.parts:
        raise ValueError(f"unsafe directory path: {raw}")
    return Path(*pure.parts)


def expand_directories(raw_dirs: list[str]) -> list[Path]:
    expanded: dict[str, Path] = {}
    for raw in raw_dirs:
        rel = normalize_relative_dir(raw)
        current = Path()
        for part in rel.parts:
            current = current / part
            expanded[current.as_posix()] = current
    return [expanded[key] for key in sorted(expanded.keys())]


def insert_tree(tree: dict[str, dict], path: Path) -> None:
    node = tree
    for part in path.parts:
        node = node.setdefault(part, {})


def render_tree(node: dict[str, dict], prefix: str = "") -> list[str]:
    items = sorted(node.items(), key=lambda item: item[0])
    lines: list[str] = []
    for index, (name, child) in enumerate(items):
        is_last = index == len(items) - 1
        branch = "└── " if is_last else "├── "
        lines.append(f"{prefix}{branch}{name}/")
        extension = "    " if is_last else "│   "
        lines.extend(render_tree(child, prefix + extension))
    return lines


def build_project_tree(feature_dirs: list[Path], under_modules: bool) -> str:
    lines = [
        ".",
        "├── AGENTS.md",
        "├── docs/",
        "│   ├── requirements.md",
        "│   └── structure.md",
    ]
    feature_tree: dict[str, dict] = {}
    for path in feature_dirs:
        insert_tree(feature_tree, path)

    if under_modules:
        lines.append("└── modules/")
        module_lines = render_tree(feature_tree, "    ")
        return "\n".join(lines + module_lines)

    feature_lines = render_tree(feature_tree)
    if feature_lines:
        lines.extend(feature_lines)
    return "\n".join(lines)


def build_directory_agents(template: str, relative_dir: Path) -> str:
    return template.replace("{DIR_PATH}", relative_dir.as_posix())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".", help="target project root")
    parser.add_argument(
        "--mode",
        choices=["skip", "backup", "overwrite"],
        default="backup",
    )
    parser.add_argument("--dirs", nargs="*", default=[], help="feature directories to create")
    args = parser.parse_args()

    project_root = Path(args.project_root).resolve()
    skill_dir = Path(__file__).resolve().parents[1]

    root_agents = load_template(skill_dir, "AGENTS.md")
    directory_agents_template = load_template(skill_dir, "DIRECTORY_AGENTS.md")
    structure_template = load_template(skill_dir, "structure.md")
    feature_dirs = expand_directories(args.dirs)

    primary_tree = build_project_tree(feature_dirs, under_modules=False)
    alternative_tree = build_project_tree(feature_dirs, under_modules=True)
    structure = structure_template.replace("{PRIMARY_TREE}", primary_tree)
    structure = structure.replace("{ALTERNATIVE_TREE}", alternative_tree)

    safe_write(project_root / "AGENTS.md", root_agents, args.mode)
    safe_write(project_root / "docs" / "structure.md", structure, args.mode)

    for relative_dir in feature_dirs:
        dir_path = project_root / relative_dir
        dir_path.mkdir(parents=True, exist_ok=True)
        content = build_directory_agents(directory_agents_template, relative_dir)
        safe_write(dir_path / "AGENTS.md", content, args.mode)

    print("DONE")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
