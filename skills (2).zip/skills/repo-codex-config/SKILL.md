---
name: repo-codex-config
description: Add or standardize repository-local Codex settings by creating or updating `.codex/config.toml`. Use when Codex is asked to add the standard sandbox configuration to a repo, bootstrap `.codex` settings in a project, or align an existing repo config with `approval_policy = "on-request"`, `sandbox_mode = "workspace-write"`, and `[sandbox_workspace_write] network_access = false`.
---

# Repo Codex Config

Apply the standard repo-local Codex config without overwriting unrelated settings. Prefer the bundled script because it creates `.codex/config.toml` when missing and only updates the required keys when the file already exists.

## Workflow

1. Resolve the repository root.
2. Run `scripts/apply_repo_codex_config.py` from this skill against the repo root.
3. Read the resulting `.codex/config.toml` and confirm it contains:

```toml
approval_policy = "on-request"
sandbox_mode = "workspace-write"

[sandbox_workspace_write]
network_access = false
```

## Script Usage

Run:

```bash
python "<skill-dir>/scripts/apply_repo_codex_config.py" "<repo-root>"
```

Behavior:
- Create `<repo-root>/.codex/` if needed.
- Create `<repo-root>/.codex/config.toml` if it does not exist.
- Update only `approval_policy`, `sandbox_mode`, and `sandbox_workspace_write.network_access`.
- Preserve unrelated settings and other sections.
- Print whether the file was created, updated, or already compliant.

Use `--check` when you only need to detect drift:

```bash
python "<skill-dir>/scripts/apply_repo_codex_config.py" "<repo-root>" --check
```

## Manual Fallback

If Python is unavailable or a one-off hand edit is simpler:
- Create `.codex/config.toml` with the exact block above when the file is missing.
- If the file already exists, change only the three required values and leave unrelated settings intact.
- If the file contains duplicate keys or multiple `[sandbox_workspace_write]` tables, inspect the file after editing because the repo already has invalid or ambiguous TOML.
