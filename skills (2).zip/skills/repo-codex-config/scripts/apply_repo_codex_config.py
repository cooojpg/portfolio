#!/usr/bin/env python3
"""Create or update .codex/config.toml in a repository."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


DESIRED_TOP_LEVEL = [
    ("approval_policy", '"on-request"'),
    ("sandbox_mode", '"workspace-write"'),
]
SECTION_NAME = "sandbox_workspace_write"
SECTION_KEY = ("network_access", "false")


def detect_newline(text: str) -> str:
    return "\r\n" if "\r\n" in text else "\n"


def parse_table_name(line: str) -> str | None:
    match = re.match(r"^\s*\[([^\[\]]+)\]\s*(?:#.*)?$", line)
    return match.group(1).strip() if match else None


def parse_assignment_key(line: str) -> str | None:
    stripped = line.lstrip()
    if not stripped or stripped.startswith("#"):
        return None

    match = re.match(r"^([A-Za-z0-9_-]+)\s*=.*$", stripped)
    return match.group(1) if match else None


def collect_table_spans(lines: list[str]) -> tuple[dict[str, list[tuple[int, int]]], int]:
    tables: list[tuple[str, int]] = []
    for index, line in enumerate(lines):
        table_name = parse_table_name(line)
        if table_name is not None:
            tables.append((table_name, index))

    spans: dict[str, list[tuple[int, int]]] = {}
    for index, (table_name, start) in enumerate(tables):
        end = tables[index + 1][1] if index + 1 < len(tables) else len(lines)
        spans.setdefault(table_name, []).append((start, end))

    first_section_start = tables[0][1] if tables else len(lines)
    return spans, first_section_start


def ensure_blank_line_before_index(lines: list[str], index: int, newline: str) -> int:
    if index <= 0:
        return index
    if lines[index - 1].strip():
        lines.insert(index, newline)
        return index + 1
    return index


def add_or_update_top_level(lines: list[str], newline: str) -> list[str]:
    spans, first_section_start = collect_table_spans(lines)
    del spans

    for key, value in DESIRED_TOP_LEVEL:
        matches = [
            index
            for index in range(first_section_start)
            if parse_assignment_key(lines[index]) == key
        ]
        if matches:
            lines[matches[0]] = f"{key} = {value}{newline}"
            for duplicate_index in matches[1:]:
                lines[duplicate_index] = None  # type: ignore[assignment]

    lines = [line for line in lines if line is not None]

    _, first_section_start = collect_table_spans(lines)
    missing_lines = []
    for key, value in DESIRED_TOP_LEVEL:
        found = any(
            parse_assignment_key(lines[index]) == key
            for index in range(first_section_start)
        )
        if not found:
            missing_lines.append(f"{key} = {value}{newline}")

    if missing_lines:
        insert_at = first_section_start
        lines[insert_at:insert_at] = missing_lines
        if insert_at + len(missing_lines) < len(lines):
            inserted_end = insert_at + len(missing_lines)
            ensure_blank_line_before_index(lines, inserted_end, newline)

    return lines


def add_or_update_section(lines: list[str], newline: str) -> list[str]:
    spans, _ = collect_table_spans(lines)
    target_sections = spans.get(SECTION_NAME, [])
    desired_line = f"{SECTION_KEY[0]} = {SECTION_KEY[1]}{newline}"

    if target_sections:
        start, end = target_sections[0]
        matches = [
            index
            for index in range(start + 1, end)
            if parse_assignment_key(lines[index]) == SECTION_KEY[0]
        ]
        if matches:
            lines[matches[0]] = desired_line
            for duplicate_index in matches[1:]:
                lines[duplicate_index] = None  # type: ignore[assignment]
            return [line for line in lines if line is not None]

        lines[end:end] = [desired_line]
        return lines

    if lines and lines[-1].strip():
        lines.append(newline)

    lines.extend([f"[{SECTION_NAME}]{newline}", desired_line])
    return lines


def apply_config(text: str) -> str:
    newline = detect_newline(text)
    lines = text.splitlines(keepends=True)

    lines = add_or_update_top_level(lines, newline)
    lines = add_or_update_section(lines, newline)

    updated = "".join(lines)
    if not updated.endswith(newline):
        updated += newline
    return updated


def write_text(path: Path, text: str) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        handle.write(text)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create or update a repo-local .codex/config.toml file."
    )
    parser.add_argument("repo_root", help="Path to the repository root")
    parser.add_argument(
        "--check",
        action="store_true",
        help="Exit with status 1 when the repo config is missing or would change",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    repo_root = Path(args.repo_root).expanduser().resolve()

    if not repo_root.exists() or not repo_root.is_dir():
        print(f"error: repository root does not exist: {repo_root}", file=sys.stderr)
        return 2

    config_dir = repo_root / ".codex"
    config_path = config_dir / "config.toml"
    original = config_path.read_text(encoding="utf-8") if config_path.exists() else ""
    updated = apply_config(original)
    changed = (not config_path.exists()) or updated != original

    if args.check:
        if changed:
            print(f"needs update: {config_path}")
            return 1
        print(f"already compliant: {config_path}")
        return 0

    if not config_path.exists():
        config_dir.mkdir(parents=True, exist_ok=True)
        write_text(config_path, updated)
        print(f"created: {config_path}")
        return 0

    if updated != original:
        write_text(config_path, updated)
        print(f"updated: {config_path}")
        return 0

    print(f"already compliant: {config_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
