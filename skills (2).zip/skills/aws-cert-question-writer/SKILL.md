---
name: "aws-cert-question-writer"
description: "Create, review, or rewrite AWS certification-style practice questions that are original and safe to publish. Use when Codex needs to draft AWS exam study questions, answer rationales, domain-balanced question sets, or compliance reviews for SAA-C03 and other AWS certifications. Refuse requests to reproduce real exam questions, past questions, dumps, memory-based content, or actual exam material; redirect those requests into original understanding-check problems built from the current official AWS exam guide and AWS service documentation."
---

# AWS Cert Question Writer

Create or audit original AWS certification-style study questions from public AWS documentation. Keep the output aligned to the official exam guide, but do not recreate confidential exam items.

## Safety Gate

- Read [references/official-sources.md](references/official-sources.md) before drafting or reviewing questions.
- Refuse requests that ask for real exam questions, past questions, dumps, leaks, recalled items, "actual exam" content, or "same as the exam" content.
- Treat phrases such as `本試験で出た`, `過去問`, `的中問題`, `受験者から聞いた問題`, `memory-based`, and `brain dump` as hard stops.
- If the user provides suspected exam content, do not answer it, paraphrase it, translate it, or use it as a base. Explain that AWS Certification materials are confidential and ask for a topic, service, or exam domain instead.
- Do not promise legal certainty. State that the workflow is designed to reduce risk by avoiding AWS confidential exam content and relying on public AWS documentation, and that it is not legal advice.
- Redirect unsafe requests into safe alternatives:
  - original practice questions
  - understanding-check questions
  - exam-guide-aligned study sets
  - compliance review of draft questions

## Source Policy

- Use the current official AWS Certification exam guide for the requested exam. Do not rely on memory for domain names, weights, question format, or in-scope services.
- Use current AWS public documentation for service behavior, configuration rules, durability, connectivity options, storage classes, and operational tradeoffs when they matter to the answer.
- Use AWS pricing pages when the answer depends on cost.
- Prefer official AWS sources only:
  - AWS Certification Program Agreement
  - AWS Certification exam guides
  - AWS service documentation
  - AWS pricing pages
  - AWS FAQs when the user is comparing services
- Record `最終確認日` with an absolute date on every question or question set.
- Include the exact public URLs used for the rationale.
- Re-verify unstable or easily outdated facts before finalizing the answer.

## Workflow

### 1. Identify scope

- Determine the target certification, such as `SAA-C03`. If the user does not specify it, ask once or clearly state the assumption.
- Determine the deliverable:
  - one question
  - a small set
  - a full blueprint
  - a compliance review of existing draft questions

### 2. Build an exam-aligned blueprint

- Map the requested question count to the current domain weights from the official exam guide.
- For large sets, show the planned domain distribution before drafting the whole set.
- Keep one learning objective per question.
- Choose one dominant decision axis per question:
  - security
  - resilience
  - performance
  - cost
  - operational tradeoff
- Add explicit constraints so one answer is best:
  - minimize operational overhead
  - avoid internet traversal
  - minimize RTO
  - keep application changes minimal
  - minimize cost while preserving immediate retrieval

### 3. Draft original questions

- Use scenario-based wording instead of pure term-definition questions.
- Keep each question focused on a single core topic or service decision.
- Use plausible distractors that a partially prepared learner might choose.
- Avoid joke options, obviously wrong options, obscure edge-case trivia, wording traps, and stale specifications.
- Do not imitate a known exam question more closely than necessary. Build a fresh scenario, actors, constraints, and choice set.

### 4. Write rationales

- State the correct answer clearly.
- Explain why it is the best fit for the stated constraints.
- Explain why each other option is incorrect or less suitable.
- Link to the public AWS sources that support the explanation.
- Add metadata:
  - `試験`
  - `ドメイン`
  - `難易度`
  - `関連サービス`
  - `最終確認日`
  - `参考ドキュメントURL`

### 5. Review before returning

- Check that the question is original and not derived from recalled exam content.
- Check that the stated constraints make the answer uniquely best.
- Check that each distractor is plausible but still incorrect or suboptimal.
- Check that every technical claim is supported by current AWS docs.
- Replace risky phrasing with safer wording from [references/official-sources.md](references/official-sources.md).
- If reviewing a user draft, flag:
  - compliance risk
  - ambiguity
  - outdated service assumptions
  - weak distractors
  - missing rationale
  - missing source links

## Output Shape

- Load [references/question-template.md](references/question-template.md) when drafting the final output.
- Use labels such as `オリジナル練習問題` and `理解確認問題`.
- Avoid labels such as `過去問`, `本試験`, `的中`, `実際に出た`, and `公式問題`.
- When producing many questions, provide:
  1. a domain distribution table
  2. the questions
  3. an audit checklist summary

## SAA-C03 Note

- If the task is about `SAA-C03`, expect architecture-oriented domains, but copy the live domain names, weights, and response format from the current official guide each time.
- Do not rely on embedded historical weights or sample splits in this skill without re-checking the live guide first.
