# Official AWS Sources and Safety Notes

Use these public sources and refresh them with the web tool before finalizing questions.

## Primary sources

- AWS Certification Program Agreement  
  `https://aws.amazon.com/certification/certification-agreement/`
- AWS Certified Solutions Architect - Associate (SAA-C03) exam guide  
  `https://docs.aws.amazon.com/aws-certification/latest/userguide/solutions-architect-associate-03.html`
- Alternate AWS Documentation page for the same SAA-C03 guide  
  `https://docs.aws.amazon.com/aws-certification/latest/solutions-architect-associate-03/solutions-architect-associate-03.html`
- AWS Documentation home  
  `https://docs.aws.amazon.com/`
- AWS Pricing  
  `https://aws.amazon.com/pricing/`

## What to confirm from official sources

- From the Certification Program Agreement:
  - exam materials are confidential
  - do not use disclosed, copied, reproduced, transmitted, distributed, or derivative exam content
  - do not use unauthorized content disclosures
- From the exam guide:
  - current domain names
  - current weights
  - response types
  - in-scope services
  - the design emphasis for the exam
- From service docs and pricing pages:
  - current behavior
  - current best practices
  - current cost tradeoffs

## SAA-C03 live-check reminder

Before writing for `SAA-C03`, re-open the current guide and copy:

- the exact domain names
- the exact domain weights
- the current response formats

If multiple AWS pages disagree, prefer the latest AWS documentation page you can verify and record the URLs you actually used.

## Reject these request patterns

- `本試験で出た問題`
- `実際に出題された問題`
- `過去問`
- `的中問題`
- `受験者から聞いた問題`
- `本番と同じ問題`
- `actual exam`
- `real exam questions`
- `brain dump`
- `memory-based questions`

## Prefer these phrases

- `オリジナル練習問題`
- `理解確認問題`
- `試験ガイドに基づく学習問題`
- `SAA-C03範囲に沿った演習問題`
- `AWS公式ドキュメントに基づく解説付き問題`

## Safe response language

Use wording like this when the user is worried about legal or policy risk:

`この進め方は、AWSの公開ドキュメントだけを根拠にして、実試験の機密問題を使わずにオリジナル問題を作るため、リスクを下げる設計です。ただし、法的判断そのものではないため、必要なら専門家確認も検討してください。`

## If the user provides suspicious source material

- Do not transform it.
- Do not summarize it.
- Do not convert it into "similar" questions.
- Refuse and ask for a clean topic list, domain list, or service list instead.
