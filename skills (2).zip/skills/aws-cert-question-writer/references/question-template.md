# Question and Review Templates

Load this file when drafting the final output or auditing a user-provided question set.

## Batch blueprint template

```md
## 問題セット設計

- 試験:
- 総問題数:
- 最終確認日:
- 参照した公式URL:
  - 
  - 

| ドメイン | 比率 | 目標問題数 | 主なテーマ |
|---|---:|---:|---|
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
```

## Single-question template

```md
## 問題

ある企業は、...
<要件、制約、優先順位を明確に書く>
最も適切な対応はどれですか。

A. ...
B. ...
C. ...
D. ...

## 正解

A. ...

## 解説

<なぜ正解が要件に最も合うか>

## 他の選択肢が違う理由

- B: ...
- C: ...
- D: ...

## 分類

- 試験:
- ドメイン:
- 難易度:
- 関連サービス:
- 最終確認日:
- 参考ドキュメントURL:
  - 
  - 
```

## Batch allocation hints

Derive target counts from the live official domain weights instead of hard-coding a split.

Recommended process:
- multiply total question count by each verified domain weight
- round to nearest practical whole-question allocation
- adjust the final 1 to 2 questions so the total matches exactly
- document how rounding was handled when the totals do not divide evenly

## Review checklist

- Is the question clearly original rather than reconstructed from exam memory?
- Does the prompt state the constraints that make one answer best?
- Are the distractors plausible AWS options rather than obvious nonsense?
- Is the answer still correct under the latest AWS docs?
- Does the explanation say why the other choices are worse?
- Are `最終確認日` and official URLs present?
- Does the wording avoid `過去問`, `本試験`, `的中`, `実際に出た`, and similar claims?
