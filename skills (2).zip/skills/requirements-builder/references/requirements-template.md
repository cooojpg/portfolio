# {PROJECT_NAME}

<!--
生成元: requirements-builder skill for Codex
生成日: {YYYY-MM-DD}
モード: {A | B | Hybrid}
-->

## 概要

{プロジェクトの目的を 1〜3 文で書く。Web アプリ / CLI / ライブラリ / ML / インフラ のどれに近いかが分かる粒度にする}

<!-- fidelity: {high|mid|low}, source: {READMEや対話など} -->

---

## プロジェクト種別

{Web アプリ / CLI ツール / ライブラリ / ML / 研究リポジトリ / インフラ / その他}

<!-- fidelity: {level}, source: {source} -->

---

## ターゲットユーザー / ステークホルダー

{誰のためのプロジェクトか。個人開発 / チーム / 公開 OSS / 内部利用 などを明示}

<!-- fidelity: {level}, source: {source} -->

---

## 機能要件

主要機能を bullet で列挙する。各機能は 1 行で書き、必要に応じて補足を sub-bullet に書く。

- {主要機能 1}
- {主要機能 2}
- {主要機能 3}

<!-- fidelity: {level}, source: {source} -->

---

## 非機能要件

> 各項目は必ず `該当` または `該当なし` が判断できる書き方にする。空欄や `TBD` だけで終わらせない。

### セキュリティ

{認証・認可 / 秘密情報 / 公開境界 / 外部 IdP の有無を書く。該当しないなら「該当なし」}

<!-- fidelity: {level}, source: {source} -->

### テスト・検証

{テストフレームワーク / CI / 手動検証方針 / 品質基準を書く。該当しないなら「該当なし」}

<!-- fidelity: {level}, source: {source} -->

### デプロイ・運用

{ローカルのみ / 単一環境 / 多環境 / IaC の有無を書く。該当しないなら「該当なし」}

<!-- fidelity: {level}, source: {source} -->

### ドキュメント整備

{README 以外の仕様書 / ガイド / 運用メモの要否を書く。該当しないなら「該当なし」}

<!-- fidelity: {level}, source: {source} -->

### データ・永続化

{DB / ファイル / キャッシュ / 外部ストレージ / マイグレーションの要否を書く。該当しないなら「該当なし」}

<!-- fidelity: {level}, source: {source} -->

### 外部連携

{外部 API / Webhook / SaaS / 認証基盤連携の有無を書く。該当しないなら「該当なし」}

<!-- fidelity: {level}, source: {source} -->

---

## 想定変更規模 / スコープ

{今後想定される変更規模を書く}

- 機能追加の頻度: {高 / 中 / 低}
- 設計変更の見込み: {あり / 限定的 / 当面なし}
- 想定される変更単位: {1 ファイル / 数ファイル / 領域横断}

<!-- fidelity: {level}, source: {source} -->

---

## 制約・トレードオフ

(任意)

{技術選定上の制約、性能と保守性のバランス、依存関係制約などがあれば書く}

<!-- fidelity: {level}, source: {source} -->

---

## スコープ外

(任意)

{明示的にやらないことがあれば書く}

- {やらないこと 1}
- {やらないこと 2}

<!-- fidelity: {level}, source: {source} -->

---

## ディレクトリ構造案

(任意。書く場合はヘッダ名を変えない。bullet はコードフェンスで囲まない)

- {top1}
- {top2}
  - {nested1}
  - {nested2}
- {top3}

<!-- fidelity: {level}, source: {source} -->

---

## 複雑度別タスク例 (S / M / L / X)

(任意)

- **S (single file / typo / format)**: {例}
- **M (2〜5 files / 1〜2 領域)**: {例}
- **L (6+ files / 3+ 領域 / 新機能)**: {例}
- **X (横断ルール / 認証境界 / データ形式 / 大規模リファクタ)**: {例}

<!-- fidelity: {level}, source: {source} -->

---

## 未決事項

(対話で未回答だった項目や、抽出できなかった必須項目を残す)

| 項目 | 暫定値 | 判断保留の理由 | 確定時期の目安 |
|---|---|---|---|
| {例: ターゲットDB} | {暫定: PostgreSQL} | {評価が終わっていない} | {YYYY年Qx} |

---

<!--
各セクション末尾の HTML コメント `<!-- fidelity: high|mid|low, source: <path> -->` は、
内容の根拠と確度を示す。

- fidelity: high  -> 専用セクション、既存 requirements、ADR、複数ソース一致
- fidelity: mid   -> README や manifest description からの要約
- fidelity: low   -> 散文や薄い文脈からの推定

未解決の必須項目を本文に暫定値で書くときは `<!-- 推定: <根拠> -->` を併記する。
テンプレート内の `{level}` `{source}` は必ず実値に置換するか、不要ならコメントごと削除する。
-->
