---
name: requirements-builder
description: Create or update `docs/requirements.md` for a repository by extracting requirements from existing documentation, interviewing the user, or combining both. Use when Codex is asked to "requirements 作って", "要件書まとめて", "docs/requirements.md を作成", "要件抽出", "ヒアリングで要件を作る", or "既存ドキュメントから要件定義ドラフトを起こす". Produce a stable document with required sections for 概要, プロジェクト種別, 機能要件, 非機能要件 6 種, and 想定変更規模, and record `該当なし` explicitly instead of leaving gaps.
---

# Requirements Builder

Create a repo-local requirements document that later planning and implementation work can consume. Default to Hybrid mode: extract what the repository already says, then ask only for the missing pieces.

## Workflow

### 1. Preflight

- Resolve the repository root. Prefer `git rev-parse --show-toplevel`; fall back to the current working directory if the repo is not under git.
- Confirm that `docs/` can be created or updated.
- Detect whether `docs/requirements.md` already exists.
- Run a light source scan with `rg --files` before reading content.

If `docs/requirements.md` already exists, do not overwrite it by default. Prefer a diff-oriented update unless the user explicitly asks for full regeneration.

### 2. Choose a Mode Once

Pick the mode before drafting:

| Mode | Input | Use when |
|---|---|---|
| A: extraction only | existing repo docs | the repo already documents itself well |
| B: interview only | user answers | the repo is new or mostly empty |
| Hybrid | extraction + targeted questions | the common case |

Default rule:
- no useful documents found -> Mode B
- at least one useful document found -> Hybrid

Treat empty bootstrap files such as untouched `CLAUDE.md` or generic agent instructions as weak evidence only. Do not let boilerplate force Mode A.

### 3. Extract Evidence (Mode A / Hybrid)

Read only relevant files instead of the whole repo. Prioritize sources in this order:

1. existing `docs/requirements.md`
2. `docs/**/*.md`, `documentation/**/*.md`
3. `ARCHITECTURE.md`, `DESIGN.md`, `RFC*.md`, `ADR*.md`, `decisions/**/*.md`
4. `README*`
5. `AGENTS.md`, `CLAUDE.md`, project-specific workflow docs
6. `package.json`, `pyproject.toml`, `Cargo.toml`, `go.mod`
7. `CONTRIBUTING.md`, `SECURITY.md`
8. entrypoint comments as a last resort

Use these heuristics:
- purpose: README intro, project description fields, architecture overview
- major features: `Features`, `機能`, `Use cases`, or equivalent bullets
- non-functional requirements: `Requirements`, `Performance`, `Security`, `Compatibility`, `Operations`
- constraints: `Constraints`, `Limitations`, `Won't`, `やらないこと`
- stakeholders: `Audience`, `Target`, `ユーザー`, `利用者`
- directory structure: explicit tree or bullet layout in architecture or docs

Ignore noise:
- badges
- install/setup/quickstart steps unless they reveal a hard requirement
- changelogs and release notes
- license text
- generic contribution procedure

Track confidence with HTML comments when you draft:
- `high`: dedicated docs section, ADR, existing requirements doc, or repeated evidence
- `mid`: README summary or manifest description
- `low`: inference from sparse text or comments

### 4. Detect Gaps

After extraction, check whether the draft can fill all required sections:

- `## 概要`
- `## プロジェクト種別`
- `## 機能要件`
- `## 非機能要件`
  - セキュリティ
  - テスト・検証
  - デプロイ・運用
  - ドキュメント整備
  - データ・永続化
  - 外部連携
- `## 想定変更規模 / スコープ`

In Hybrid mode, ask only for missing or ambiguous items. In Mode A, leave unknown items as `(未記載)` or move them to `## 未決事項` if the absence matters.

### 5. Interview the User (Mode B / Hybrid)

Read `references/question-bank.md` when you need prompts.

Rules:
- Ask questions in 2 batches: Phase 1 first, then Phase 2.
- In Hybrid mode, ask only the questions that map to missing sections.
- Stop at 9 base questions. Allow at most 2 follow-up questions when ambiguity blocks the draft.
- If the user says "わからない", "未定", or "後で決める", continue and record that item in `## 未決事項`.

When a required answer is skipped, add a temporary best-effort assumption in the main body and annotate it with `<!-- 推定: <根拠> -->`.

### 6. Draft `docs/requirements.md`

Read `references/requirements-template.md` before writing.

Output rules:
- Keep every required heading from the template.
- Fill all 6 non-functional categories with either concrete text or `該当なし`.
- Replace placeholder fidelity comments with real values, or remove the comment entirely when no trustworthy source exists.
- Preserve `## ディレクトリ構造案` exactly if you include that section.
- Do not wrap the directory structure bullets in a code fence.
- Add `## 未決事項` when required answers remain open.

### 7. Review Locally Before Writing

Do one self-review pass with this checklist:

1. Are all required headings present?
2. Do all 6 non-functional categories resolve to a clear yes/no reading?
3. Are any `{level}`, `{source}`, or other template placeholders still present?
4. Do user answers contradict each other?
5. If `## ディレクトリ構造案` exists, is it a normal bullet list rather than a fenced block?

If the user explicitly asks for delegation or parallel review, you may add a second review pass with another agent. Otherwise keep the workflow single-agent.

### 8. Write the File

- If `docs/requirements.md` does not exist, create it.
- If it exists, default to a diff proposal or section-by-section update.
- Only fully replace the file when the user explicitly asks for regeneration or approves replacement.
- When fully replacing an existing file, create a timestamped backup first.

### 9. Report Back

Summarize:
- output path
- chosen mode
- main sources used
- remaining undecided items
- any assumptions or low-confidence sections that should be reviewed manually

## References

- `references/question-bank.md`: interview prompts and follow-up rules
- `references/requirements-template.md`: required output shape
