---
name: setup-project-structure
description: Set up Codex-friendly repository scaffolding by creating or updating a root `AGENTS.md`, nested directory `AGENTS.md` files, `docs/structure.md`, `tasks/` tracking files, and standard `.codex/config.toml` usage. Use when Codex is asked to create a project structure, scaffold repo conventions after `docs/requirements.md` exists, introduce hierarchical repo instructions, add task tracking files, or bootstrap a repository for repeatable Codex work.
---

# Setup Project Structure

Create the repo scaffolding that Codex can work against repeatedly: requirements in `docs/requirements.md`, structure in `docs/structure.md`, global rules in `AGENTS.md`, narrower rules in directory-local `AGENTS.md`, repo settings in `.codex/config.toml`, and work tracking in `tasks/`.

Codex does not use Claude hooks or `.claude/settings.json`. Do not copy that mechanism into a Codex repo. Use `AGENTS.md` files and explicit document updates instead.

## Workflow

### 1. Preflight

Before drafting anything:

- Resolve the repository root. Prefer `git rev-parse --show-toplevel`; otherwise use the current working directory.
- Confirm that `docs/requirements.md` exists and is not empty.
- Detect these existing files before proposing changes:
  - `AGENTS.md`
  - nested `**/AGENTS.md`
  - `.codex/config.toml`
  - `docs/structure.md`
  - `tasks/in-progress.md`, `tasks/todo.md`, `tasks/issues.md`
  - `.gitattributes`
- Detect Claude-specific files such as `CLAUDE.md` or `.claude/`, but leave them untouched unless the user explicitly asks for cross-tool parity.
- If an existing root `AGENTS.md` is present, read it before proposing replacements so user-authored conventions are not lost accidentally.

If `docs/requirements.md` is missing or empty, stop and ask the user to create it first. Prefer `requirements-builder` for that step.

### 2. Decide Existing-File Policy Once

If the repo already contains any managed files, confirm one policy once and keep it for the whole run:

- A: back up existing managed files with `.bak.YYYYMMDD-HHMMSS`, then regenerate
- B: overwrite existing managed files directly
- C: confirm file-by-file
- D: keep existing files and create only missing ones

Rules:
- `tasks/*.md` should default to skip when they already exist, because they carry live work state.
- If `.gitattributes` already exists, prefer merge or append instead of full replacement.
- If both `AGENTS.md` and `CLAUDE.md` exist, do not try to unify them automatically unless the user asks.
- If policy `C` or `D` is chosen and a root `AGENTS.md` already exists, preserve the user's sections and append only missing scaffold guidance. Read `references/existing-file-policy.md` before editing.
- If no managed file will be overwritten and the task is only adding missing standard files, default to policy `D` without stopping for a separate confirmation.

### 3. Extract Structure Hints from `docs/requirements.md`

Read the full requirements document.

Preferred input pattern:
- the dedicated directory-structure section produced by `requirements-builder`, written as a normal Markdown bullet tree

If that section exists:
- parse it directly
- treat 2-space indentation as canonical
- if tabs or inconsistent indentation appear, explain the interpretation and ask before writing

If the section does not exist:
- infer candidate top-level directories from bullets, inline `name/` mentions, and feature groupings
- synthesize a primary and alternative structure from the requirements
- consult `references/default-layouts.md` for project-type defaults before inventing a layout from scratch
- prefer shallow proposals when the requirements are underspecified
- do not invent more than 2 new nesting levels unless the requirements clearly imply layer boundaries

### 4. Draft a Structure Proposal

Prepare:
- one primary structure
- one alternative structure
- short rationale for each
- key decisions and tradeoffs
- the default `AGENTS.md` placement policy

Default `AGENTS.md` placement policy:
- create a root `AGENTS.md`
- create directory-local `AGENTS.md` in each managed feature directory
- create nested `AGENTS.md` down the approved tree unless the user explicitly opts out for some paths
- if a directory is new and still empty, keep its `AGENTS.md` brief and factual instead of inventing fake entrypoints

If the user explicitly asks for multiple viewpoints or delegation, you may run a separate architect and reviewer pass with subagents. Otherwise do this locally in a single-agent flow.

### 5. Get Approval Before Writing

When the task would change repository structure, overwrite managed files, or there are multiple viable layouts, pause once and show:
- primary structure
- alternative structure
- rationale
- directories where `AGENTS.md` will be created
- any existing files that would be changed, skipped, or backed up

If the user already asked to scaffold, the structure is already clear from `docs/requirements.md`, and the chosen policy only adds missing files or appends safe guidance, summarize the intended writes briefly and proceed without a second approval round.

### 6. Generate the Scaffold

After approval, or immediately when the Step 5 fast path applies:

1. Ensure `.codex/config.toml` is present.
   - Prefer using `$repo-codex-config` if available.
   - Fallback: create the standard config manually.
2. Create or update `docs/structure.md` from `references/structure-template.md`.
3. Create or update the root `AGENTS.md` from `references/root-agents-template.md`.
4. Create approved directories and add directory-local `AGENTS.md` files using `references/directory-agents-template.md`.
5. Create `tasks/` files from `references/task-templates.md` only when missing or when the chosen policy allows replacement.
6. Merge the `.gitattributes` snippet from `references/gitattributes-snippet.md`.
7. Follow `references/existing-file-policy.md` whenever an existing managed file needs merge-vs-replace handling.

Managed fixed scaffold:

```text
.
|- .codex/
|  `- config.toml
|- docs/
|  |- requirements.md
|  `- structure.md
|- tasks/
|  |- in-progress.md
|  |- todo.md
|  `- issues.md
|- .gitattributes
`- AGENTS.md
```

### 7. Write `AGENTS.md` Files Correctly

For the root `AGENTS.md`:
- keep repo-wide change policy
- make `docs/structure.md` the source of truth for structure
- define how nested `AGENTS.md` files narrow scope
- define `tasks/` usage

For directory-local `AGENTS.md`:
- describe that directory's purpose
- summarize major contents, public entrypoints, external dependencies, and data flow when relevant
- list local requirements, constraints, and edit notes

When a directory has no stable local rules yet, keep the file short rather than inventing fake constraints. If the directory is empty, write `not established yet` for entrypoints or contents instead of guessing.

### 8. Review After Generation

Read the generated files and check:

1. `docs/structure.md` matches the approved tree
2. the root `AGENTS.md` does not mention Claude-only hooks
3. nested `AGENTS.md` files reflect the actual directory purpose
4. `tasks/` files were not overwritten unexpectedly
5. `.codex/config.toml` exists and matches the standard config

### 9. Report Back

Summarize:
- created files
- updated files
- skipped files and why
- backup files, if any
- paths where `AGENTS.md` was intentionally omitted
- any sections that still need the user to fill in manually

## References

- `references/root-agents-template.md`: root repo instructions template
- `references/directory-agents-template.md`: per-directory instructions template
- `references/structure-template.md`: `docs/structure.md` template
- `references/task-templates.md`: `tasks/` file templates
- `references/gitattributes-snippet.md`: mergeable `.gitattributes` snippet
- `references/default-layouts.md`: default layouts for common project types
- `references/existing-file-policy.md`: how to merge or preserve existing scaffold files
