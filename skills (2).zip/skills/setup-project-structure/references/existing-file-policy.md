# Existing File Policy

Apply these rules after the user chooses policy `A`, `B`, `C`, or `D`.

---

## `AGENTS.md`

- `A`: back up the existing file, then regenerate from the template and re-apply any still-relevant user guidance
- `B`: replace directly only when the user has explicitly accepted overwrite risk
- `C`: show a short diff summary and confirm section-by-section when the existing file is substantial
- `D`: preserve the existing file and append only missing scaffold sections needed for structure, tasks, or repo settings

When appending to an existing root `AGENTS.md`:

- keep the user's original sections intact
- prefer adding new top-level headings rather than editing their prose
- avoid duplicating guidance that already exists semantically

For child `AGENTS.md` files:

- preserve existing files when they already describe the directory well
- create only missing child files unless the chosen policy explicitly allows replacement

---

## `tasks/*.md`

- default to preserve existing files under all policies unless the user explicitly asks to reset them
- if a task file is missing, create only the missing file
- never delete active task context without explicit approval

---

## `.gitattributes`

- append only the missing lines from `references/gitattributes-snippet.md`
- do not remove unrelated attributes
- if the file already pins line endings differently for the same path, stop and ask the user

---

## `docs/structure.md`

- if missing, create it
- if present and policy `D` is chosen, prefer updating the sections that represent the new approved structure rather than full replacement
- if present and policy `C` is chosen, summarize the structural differences before editing

---

## `.codex/config.toml`

- if missing, create it
- if present, update only the standard repo-local Codex keys instead of replacing unrelated config
