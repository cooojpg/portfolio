# {DIR_NAME}

## Purpose

Describe this directory's responsibility in 1 or 2 lines.

---

## Overview

This section helps Codex quickly understand the local area. It does not need to be exhaustive.

If the overview becomes stale, trust the actual files and update this document.

### Major Contents

List the important files or child directories directly under this directory and give each one short role text.

Examples:

- `index.ts` - public entrypoint for this directory
- `service/` - business logic for the feature
- `repository/` - persistence layer

### Public Entrypoints

List the functions, classes, commands, or modules that other directories call.
If none or not established yet, write `internal use only` or `not established yet`.

### External Dependencies

List meaningful outside dependencies such as services, SDKs, infrastructure modules, or sibling directories.
If none, write `none`.

### Data Flow

When relevant, summarize input -> processing -> output in 1 to 3 lines.
If the directory is empty and the data flow is not known yet, say `not established yet`.

---

## Requirements

- List the local requirements this directory must satisfy
- Add only requirements that matter here

## Constraints

- List local constraints or prohibited changes
- Keep shared constraints in a higher-level `AGENTS.md`

## Edit Notes

- Record local testing or verification expectations
- Note important coupling or impact radius
- Keep the file brief when the directory is newly created and still empty
