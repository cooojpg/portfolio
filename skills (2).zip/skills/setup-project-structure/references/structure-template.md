# Project Structure Definition

> Current adopted structure: Primary
> If you switch structures, update this line and the corresponding section.

This file is the source of truth for the repository structure.
Update this file before making structure-changing file operations.

---

## Fixed Scaffold

These files and directories are common regardless of the feature layout:

```text
.
|- .codex/
|  `- config.toml
|- docs/
|  |- requirements.md
|  `- structure.md
|- tasks/
|  |- in-progress.md
|  |- todo.md
|  `- issues.md
|- .gitattributes
`- AGENTS.md
```

The feature directories are described below.

---

## Primary Structure

```text
{PRIMARY_TREE}
```

**Rationale**

{PRIMARY_RATIONALE}

---

## Alternative Structure

```text
{ALT_TREE}
```

**Rationale**

{ALT_RATIONALE}

**Choose this when**

{ALT_WHEN_TO_CHOOSE}

---

## Key Decisions

{KEY_DECISIONS}

---

## `AGENTS.md` Placement Policy

- root `AGENTS.md` always exists
- each managed feature directory may contain its own `AGENTS.md`
- lower directories narrow scope and add detail

### Paths Intentionally Without `AGENTS.md`

{AGENTS_OMITTED_DIRS}

---

## Review Notes

{REVIEW_CONCERNS}

---

## Structure Change Procedure

1. Get explicit approval for the structure change
2. Update this file first
3. Then perform the file or directory changes
4. Update affected `AGENTS.md` files if the local meaning changed
