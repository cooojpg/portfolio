# `.gitattributes` Snippet

Merge or append this snippet instead of replacing an existing `.gitattributes` file:

```gitattributes
# Keep shell scripts and Codex repo settings on LF line endings.
*.sh text eol=lf
.codex/config.toml text eol=lf
```
