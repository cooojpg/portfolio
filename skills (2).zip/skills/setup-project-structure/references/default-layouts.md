# Default Layout Heuristics

Use these defaults only when `docs/requirements.md` does not already provide a usable `## ディレクトリ構造案`.

General rules:

- Prefer shallow structures over speculative depth.
- Do not create more than 2 inferred nesting levels unless the requirements clearly describe separate layers.
- Keep the primary proposal conservative and the alternative proposal more opinionated.

---

## Web Application

Primary:

```text
.
|- frontend/
|- backend/
|  |- api/
|  |- services/
|  `- repositories/
`- infra/
   |- environments/
   `- modules/
```

Alternative:

```text
.
|- app/
|  |- frontend/
|  `- backend/
`- platform/
   |- environments/
   `- modules/
```

Use when:
- frontend and backend are both explicit
- infrastructure is part of the same repository

---

## CLI Tool

Primary:

```text
.
|- src/
|  |- commands/
|  |- config/
|  |- integrations/
|  `- output/
`- tests/
```

Alternative:

```text
.
|- src/
|  |- app/
|  `- lib/
`- tests/
```

Use when:
- commands, external integrations, and output formatting are distinct concerns

---

## Library

Primary:

```text
.
|- src/
|- tests/
`- examples/
```

Alternative:

```text
.
|- packages/
|  `- core/
|- tests/
`- examples/
```

Use when:
- there is a single consumable package and tests are first-class

---

## ML / Research

Primary:

```text
.
|- src/
|  |- data/
|  |- train/
|  `- eval/
|- notebooks/
`- tests/
```

Alternative:

```text
.
|- pipelines/
|- experiments/
|- notebooks/
`- tests/
```

Use when:
- data preparation, training, and evaluation are distinct

---

## Infrastructure / IaC

Primary:

```text
.
|- environments/
|- modules/
`- scripts/
```

Alternative:

```text
.
|- stacks/
|- modules/
`- tooling/
```

Use when:
- reusable modules and environment composition are the main split
