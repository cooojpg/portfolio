# `tasks/` Templates

Use these templates when creating missing task tracking files.

---

## `tasks/in-progress.md`

```md
# In-Progress Tasks

This file records the current working context for active tasks.

## Rules

- Read this file at the start of a new session
- Move a task here from `tasks/todo.md` when work starts
- Remove it when complete
- If work stops mid-task, update the next action before leaving it

## Format

### {Task Name}

- Started: YYYY-MM-DD
- Related requirements: {docs/requirements.md section or "-"}
- Related files: {main file paths}
- Status: {1 to 3 lines}
- Next action: {next concrete step}
- Blockers: {none or details}
```

---

## `tasks/todo.md`

```md
# TODO

This file tracks work that has not started yet.

## Rules

- Move a task to `tasks/in-progress.md` when work begins
- Append new tasks at the end
- Use a short one-line description

## Format

- [ ] {Task name} - {one-line description} (related: {requirement or structure reference})
```

---

## `tasks/issues.md`

```md
# Issues and Constraints

This file tracks known issues, debt, tradeoffs, and unresolved questions.

## Rules

- Move an item out when it becomes actionable work
- Keep durable findings here, not transient execution state

## Format

### {Issue Name}

- Type: technical debt | design tradeoff | external constraint | observation | unspecified requirement
- Details: {1 to 3 lines}
- Impact: {optional}
- Mitigation: {optional}
- Related: {optional}
```
