# Project Instructions

This file defines repository-wide instructions for Codex and other coding agents.
Directory-specific details belong in the nearest child `AGENTS.md`.

---

## 1. File Change Policy

Normal edits, additions, and new files can proceed without prior approval.
Summarize the important change after the edit.

Ask before destructive or high-impact changes:

- deleting files or directories
- rewriting `docs/structure.md` in a way that changes the approved structure
- removing existing content from `tasks/in-progress.md`
- loosening a rule in an existing child `AGENTS.md`
- destructive git operations
- intentionally changing or breaking established behavior

## 2. Structure Source of Truth

- `docs/structure.md` is the source of truth for repository structure
- do not create, move, or delete structural directories unless `docs/structure.md` already reflects that change
- update `docs/structure.md` first, then perform the file operations

## 3. Hierarchical `AGENTS.md`

Each managed directory may contain its own `AGENTS.md`.

Rules:
- higher levels define broader rules
- lower levels may add detail or narrower constraints
- lower levels should not silently loosen higher-level constraints
- before editing a file in a subtree, read the nearest applicable `AGENTS.md` chain if it is not already in context

When files, public entrypoints, or data flow change inside a directory, update that directory's `AGENTS.md` overview section in the same task.

## 4. Requirements

- `docs/requirements.md` is the source of truth for feature and non-functional requirements
- read it before major implementation work
- update it before implementing requirement changes

## 5. Task Tracking

Work state lives in `tasks/`:

- `tasks/in-progress.md` for active work
- `tasks/todo.md` for not-yet-started tasks
- `tasks/issues.md` for known constraints, debt, or unresolved questions

Rules:
- read `tasks/in-progress.md` at the start of a new session
- move a task from `todo` to `in-progress` when starting it
- remove it from `in-progress` when done, and move unresolved fallout to `issues` if needed
- record only work state in `tasks/`; record durable design decisions in `docs/` or the appropriate `AGENTS.md`

## 6. Codex Repo Settings

- keep `.codex/config.toml` in the standard repo-local form
- if the file is missing or drifted, update it before relying on repo-local Codex defaults

## 7. Cross-Tool Files

- if `CLAUDE.md` or `.claude/` exists, treat them as supplemental tooling files
- do not delete or rewrite cross-tool files unless the user explicitly asks for that

## 8. Environment

- prefer LF line endings for shell scripts and generated repo metadata
- keep instructions short and maintainable
- if a child `AGENTS.md` becomes stale, update it after the code change that made it stale
