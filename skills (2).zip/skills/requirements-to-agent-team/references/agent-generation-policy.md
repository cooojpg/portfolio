# Agent Generation Policy for Codex

## 汎用性

この skill は任意のプロジェクトで使えるようにする。
特定ドメインや特定ツール前提を埋め込まない。

## 入口は `docs/agent-team/agent-router.md`

Agent Team の routing と delegation 判断は必ず `docs/agent-team/agent-router.md` を中心に行う。
詳細な orchestration は `docs/agent-team/team-patterns.md` に切り出す。

## Codex の機構モデル

- 起動主体は常にメイン Codex ループ
- 子 agent はさらに agent を spawn しない
- repo-local `.codex/config.toml` は `[agents]` `max_threads = 12`、`max_depth = 1` を設定する
- coordinator と Specialist は基本的に read-only で、指示書や brief を返す
- implementer と docs-writer は bounded write scope を持つ worker として扱う
- `wait_agent` は次のクリティカルパスがブロックされる時だけ使う
- 並列実行は `spawn_agent` で独立した観点を同時に走らせることを意味する
- 同時 open agent thread は最大 12 とし、上限に近い場合は完了済み agent を close してから次を起動する
- Agent Team は Standard Agent Lifecycle (`整理 -> 作業 -> レビュー / 検証 -> 完了処理`) に従って起動する
- implementer / docs-writer worker は Phase 1 整理で write scope と未決事項が明確になってから起動する
- reviewer / tester は Phase 1 の事前観点と Phase 3 の最終確認を区別して起動する
- Phase 3 で blocking finding が出た場合は Phase 4 へ進まず、Phase 2b 修正作業と Phase 3b 再レビュー / 再検証を回す

worker として起動しうる prompt には必ず以下を含める:
- あなたはコードベースに一人ではない
- 他者の変更を revert しない
- write scope 衝突を見つけたら編集前に報告する

## Delegation Gate

複数 agent 実行は、ユーザーが明示的に delegation / subagents / parallel agents / agent team を要求したときだけ有効。
要求がない場合でも、routing 文書と prompt テンプレートは作ってよいが、その場で自動 spawn してはいけない。

## 動的 Core role 選定

| Core role | 必須 / 条件付き | 生成条件 |
|---|---|---|
| coordinator | 必須 | 常に生成 |
| implementer | 必須 | 常に生成 |
| reviewer | 必須 | 常に生成 |
| planner | 条件付き | 計画作業がある |
| tester | 条件付き | テスト・検証要件がある |
| security | 条件付き | 認証・認可・秘密情報・公開境界・権限の要件がある |
| devops | 条件付き | ユーザー向けデプロイがあり、複数環境または IaC がある |
| docs-writer | 条件付き | 公開文書、仕様書要求、運用手順整備のいずれかがある |

省略した Core role は router と README に理由付きで記録する。
省略観点は coordinator が fallback する。

## Specialist 命名規則

- ドメインが明確: `<domain>-specialist.md`
- パス由来の責務で十分: `<path>-specialist.md`
- 同一ドメインで関心を分ける必要がある場合のみ: `<domain>-<concern>-specialist.md`
- `-domain-` / `-infra-` のような冗長語は避ける

原則として以下には Specialist を作らない:
- `components`
- `utils`
- `types`
- `constants`
- 一時ディレクトリ
- 責務が薄い補助ディレクトリ

## 複雑度マッピング

このマッピングは `agent-router.md`、`team-patterns.md`、ルート `AGENTS.md` の 3 箇所に mirror する。

| 複雑度 | 判定基準 | delegation が有効なときの推奨パターン |
|---|---|---|
| S | 1 ファイル / 単一責務 / 軽微修正 | local 実行、または単一 Specialist / implementer |
| M | 2〜5 ファイル / 1〜2 領域 | coordinator → 並列で Specialist + reviewer + optional tester → worker 実装 |
| L | 6 ファイル以上 / 3 領域以上 / 新機能 | coordinator + planner → 並列で Specialist 群 + reviewer + optional tester → worker 実装 → レビュー → 必要なら修正 cycle → 集約 |
| X | 横断ルール変更 / 認証境界 / データ形式 / 大規模リファクタ | 専用パターン security / perf / refactor / migration |

## Standard Agent Lifecycle

この lifecycle は `agent-router.md`、`team-patterns.md`、`README.md`、ルート `AGENTS.md` に mirror する。

| Phase | 起動する role | 完了条件 |
|---|---|---|
| Routing | 原則 spawn なし。迷う場合のみ coordinator | S / M / L / X、対象 Specialist、必要 Core role が決まる |
| 整理 | coordinator, planner, relevant Specialist, optional security/devops/tester/reviewer | 方針、risk、write scope、検証観点が明確になる |
| 作業 | implementer, docs-writer, devops worker | worker が変更ファイルと要約を返し、scope 衝突がない |
| レビュー / 検証 | reviewer, tester, security/devops re-check | blocking finding がなくなり、残項目が follow-up または accepted risk として整理され、必要な検証が通る |
| 完了処理 | coordinator またはメイン Codex | tasks 更新、docs 更新、検証結果、残リスクが整理される |

## Review Iteration Loop

Phase 3 で blocking finding が出た場合は、以下を `agent-router.md` と `team-patterns.md` に明記する。

1. coordinator またはメイン Codex が findings を `blocking` / `follow-up` / `accepted risk` に分類する
2. blocking finding ごとに最小 write scope と担当 worker を決める
3. Phase 2b 修正作業として implementer / docs-writer / devops worker を起動する
4. Phase 3b 再レビュー / 再検証として同じ観点の reviewer / tester / security / devops を再起動する
5. blocking finding がなくなるまで繰り返し、scope が広がる場合は Phase 1 に戻す
6. 残す finding は `tasks/todo.md` または `tasks/issues.md` に明示してから完了処理へ進む

## Role と `agent_type` の対応

| Role | 推奨 `agent_type` | 理由 |
|---|---|---|
| coordinator | `default` | 計画と集約で広い文脈を扱う |
| planner | `default` | 作業分解とリスク整理を行う |
| implementer | `worker` | 明示的な write ownership を持つ |
| reviewer | `explorer` | read-only の具体的レビューに向く |
| tester | `worker` または `explorer` | コマンド実行時は worker、計画だけなら explorer |
| security | `explorer` | read-only の脅威確認に向く |
| devops | `worker` または `default` | config edit やコマンド実行がある場合は worker |
| docs-writer | `worker` | ドキュメント編集を担う |
| specialist | `explorer` | read-only の領域分析に向く |

## 推奨出力レイアウト

```text
docs/agent-team/
|- agent-router.md
|- team-patterns.md
|- README.md
`- prompts/
   |- core/
   `- generated/
```

ルート `AGENTS.md` に `docs/agent-team/` の入口を追記し、`docs/structure.md` に mapping table を足す。

## `tasks/` 方針

- `tasks/todo.md` は追記のみ
- durable notes は `tasks/issues.md` を優先
- repo が既に `tasks/lessons.md` を使っているなら新しい慣習を増やさずそこへ追記する

## 完了条件

- `docs/agent-team/agent-router.md` があり、delegation gate と S / M / L / X が埋まっている
- `docs/agent-team/team-patterns.md` があり、M / L / X と X 専用パターンがある
- `docs/agent-team/team-patterns.md` と `agent-router.md` に Phase 2b / Phase 3b の review iteration loop がある
- 選定された Core prompt だけが `docs/agent-team/prompts/core/` に生成されている
- 動的命名された Specialist prompt が `docs/agent-team/prompts/generated/` に生成されている
- ルート `AGENTS.md` に Agent Team セクションがあり、delegation gate と `agents.max_threads = 12` / `agents.max_depth = 1` を明記している
- `.codex/config.toml` に `[agents]` `max_threads = 12`、`max_depth = 1` がある
- `docs/structure.md` に Agent Team Mapping がある
- `tasks/todo.md` と durable notes に未決事項が追記されている
