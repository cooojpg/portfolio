---
name: requirements-to-agent-team
description: "Codex 向けに、`docs/requirements.md`、`docs/structure.md`、ルート `AGENTS.md`、階層別 `AGENTS.md` を読み、要件と構造に適合する agent-team ルーティング文書と `spawn_agent` 用 prompt テンプレートを生成する skill。`docs/agent-team/agent-router.md` を入口に、`team-patterns.md`、`README.md`、Core role prompts、Specialist prompts、`AGENTS.md` 追記、`docs/structure.md` の agent 対応表、`tasks/todo.md` と durable task notes の追記を作る。Use when the user asks to create an agent team, delegation plan, parallel-agent workflow, subagent prompts, or says `Agent Teamを作って`, `Subagentを定義して`, `タスクごとのAgent呼び出しを定義して`, `動的にAgentを生成して` for Codex."
---

# Requirements to Agent Team

## 目的

構造決定済みリポジトリの要件と構造から、Codex 用の agent-team 文書と prompt テンプレートを動的に生成する。

Claude 用の `.claude/agents/*.md` を作るのではなく、Codex が継続的に参照できる `docs/agent-team/` と `AGENTS.md` を整備する。

## Codex の前提

- Codex には、この環境では `.claude/agents/*.md` 相当の永続的な custom subagent registry はない。永続情報は `docs/agent-team/` と `AGENTS.md` に残す。
- `spawn_agent` / `send_input` / `wait_agent` は実行時ツールであり、prompt テンプレートそのものではない。
- 複数 agent の実行は、ユーザーが明示的に delegation / subagents / parallel agents / agent team を要求した場合にだけ行う。
- 生成する文書は「いつ multi-agent を使うべきか」を定義してよいが、ユーザーが明示的に要求していない場面で自動的に spawn する規則を書いてはいけない。
- 子 agent からさらに agent を spawn させる設計にはしない。起動主体は常にメイン Codex ループ。
- repo-local `.codex/config.toml` には `[agents]` `max_threads = 12`、`max_depth = 1` を入れる。生成文書は同時 open agent thread 上限 12 とネスト深度 1 を前提にする。
- ルートと階層別の `AGENTS.md` は repo ローカルルールの正本として扱い、`docs/agent-team/` は delegation の運用資料として扱う。
- 既存の `CLAUDE.md` や `.claude/` は、ユーザーが cross-tool parity を求めた場合以外は触らない。

## 最重要原則

1. `docs/agent-team/agent-router.md` を delegation 文書の入口にする。
2. Core / Specialist role は固定ひと揃いではなく、要件と構造から動的に選定する。
3. 複雑度 M / L / X では推奨 multi-agent パターンを定義するが、実行はユーザーの明示的 delegation 要求がある場合だけに限定する。
4. Agent Team は `整理 -> 作業 -> レビュー / 検証 -> 完了処理` の Standard Agent Lifecycle で起動タイミングを揃える。
5. implementer / docs-writer worker は、整理 phase で write scope と未決事項が明確になってから起動する。
6. reviewer / tester は、作業前の事前観点と作業後の最終確認を区別して起動する。
7. Phase 3 で blocking finding が出た場合は完了処理へ進まず、Phase 2b 修正作業と Phase 3b 再レビュー / 再検証を回す。
8. 同一ファイルを編集する worker は並列不可にする。
9. `.env`、秘密情報、認証情報は読まない・表示しない・変更しない。
10. 既存文書を上書きする場合は、ユーザー指定の方針がない限り差分ベースで更新する。
11. `worker` として起動しうる prompt には shared-codebase guardrail を必ず入れる。少なくとも「一人ではない」「他者の変更を revert しない」「write scope 衝突時は編集前に報告する」を含める。

## 実行手順

### Step 1: 前提確認

- repo root を特定する。
- `docs/requirements.md`、`docs/structure.md`、ルート `AGENTS.md` の存在を確認する。
- `.codex/config.toml` の有無と `[agents]` 設定を確認する。
- 階層別 `**/AGENTS.md`、既存 `docs/agent-team/`、`tasks/todo.md`、`tasks/issues.md`、`tasks/lessons.md` を検出する。
- `CLAUDE.md` や `.claude/` があっても、ユーザーが明示しない限り参照対象に含めない。

停止条件:

- `docs/requirements.md` がない、または空なら停止し、`requirements-builder` を案内する。
- `docs/structure.md` がない、または空なら停止し、`setup-project-structure` を案内する。
- ルート `AGENTS.md` がない場合は、ユーザーがこの場で bootstrap を求めない限り停止し、`setup-project-structure` を案内する。

### Step 2: 要件と構造の読み込み

以下の観点は二値で判定する。最低条件を 1 つでも満たせば「該当」とする。

| 観点 | 該当と判定する最低条件 |
|---|---|
| セキュリティ | 認証・認可ロジックを書く / 秘密情報を扱う / 公開エンドポイントを持つ / 外部公開境界がある |
| テスト・検証 | テストフレームワーク導入済み / CI でテストが走る / 要件にテスト記述がある |
| デプロイ・運用 | ユーザー向けデプロイがある、かつ、複数環境管理または IaC が存在する |
| ドキュメント整備 | README 以外の公開文書がある / 仕様書が要求される / ユーザーガイド整備が責務に含まれる |
| データ・永続化 | DB またはファイルストレージで状態を保持する / マイグレーション管理がある |
| 外部連携 | 外部 API 呼び出し / Webhook / 外部サービス統合がある |
| 計画作業 | 機能追加、設計変更、複数ファイル変更が見込まれる |

判定結果は Step 5 の Core 選定と Step 6 の Specialist 選定に使う。

### Step 3: プロジェクトタイプ判定

最も近い種別を 1 つ選び、初期値として使う。Step 5 / 6 で増減してよい。

| 種別 | 推奨 Core role 初期値 | 推奨 Specialist 候補 初期値 |
|---|---|---|
| Web アプリ | coordinator, planner, implementer, reviewer, tester, security, devops, docs-writer | api / auth / data / ui |
| CLI ツール | coordinator, planner, implementer, reviewer, tester | command / config |
| ライブラリ | coordinator, planner, implementer, reviewer, tester, docs-writer | api / 主要モジュール |
| ML / 研究 | coordinator, planner, implementer, reviewer | data / training / eval |
| インフラ / IaC | coordinator, planner, implementer, reviewer, devops, security | terraform / k8s |
| 該当なし | coordinator, planner, implementer, reviewer | Step 6 で個別判断 |

### Step 4: タスク複雑度 S / M / L / X の定義

統一閾値:

| 複雑度 | 判定基準 |
|---|---|
| S | 1 ファイル変更 / 単一責務 / 既存パターンの軽微修正 / typo・コメント・フォーマット |
| M | 2〜5 ファイル変更 / 1〜2 領域 / 既存パターンへの追加 |
| L | 6 ファイル以上変更 / 3 領域以上 / 新機能 / 設計変更 / API 変更 |
| X | 横断ルール変更 / グローバル API 破壊 / データ形式変更 / 認証境界変更 / 段階的反復が必要 / security・perf・refactor・migration の専用パターン該当 |

判定に迷ったら一段大きい方に倒す。

プロジェクト固有例の要件:
- 各複雑度につき `対象パス + 変更内容1行` を最低 3 件書く。
- ここでの例は「delegation が明示された場合の推奨起動パターン」の判断材料として使う。

### Step 5: 動的 Core role 選定

| Core role | 必須 / 条件付き | 生成条件 |
|---|---|---|
| coordinator | 必須 | 常に生成 |
| implementer | 必須 | 常に生成 |
| reviewer | 必須 | 常に生成 |
| planner | 条件付き | Step 2 の「計画作業」が該当 |
| tester | 条件付き | Step 2 の「テスト・検証」が該当 |
| security | 条件付き | Step 2 の「セキュリティ」が該当 |
| devops | 条件付き | Step 2 の「デプロイ・運用」が該当 |
| docs-writer | 条件付き | Step 2 の「ドキュメント整備」が該当 |

省略した role は `agent-router.md` と `README.md` に必ず記録する。省略観点の fallback は coordinator に持たせる。

### Step 6: 動的 Specialist role 選定

生成対象:
- 主要責務を持つトップレベル領域
- 固有要件がある領域
- 重要なデータ、外部連携、権限、運用に関わる領域
- 変更影響が大きい領域

原則生成しない:
- `components` / `utils` / `types` / `constants`
- 小さな補助ディレクトリ
- 一時作業ディレクトリ
- 責務が薄い領域

命名規則:
- ドメインが明確: `<domain>-specialist.md`
- ドメインが曖昧でパス由来が責務と一致: `<path>-specialist.md`
- 同一ドメインで関心を分ける必要がある場合だけ: `<domain>-<concern>-specialist.md`
- `-domain-` / `-infra-` のような冗長語は付けない

### Step 7: 出力ファイルを決める

標準出力先:

```text
docs/agent-team/
|- agent-router.md
|- team-patterns.md
|- README.md
`- prompts/
   |- core/
   |  |- coordinator.md
   |  |- planner.md
   |  |- implementer.md
   |  |- reviewer.md
   |  |- tester.md
   |  |- security.md
   |  |- devops.md
   |  `- docs-writer.md
   `- generated/
      `- <dynamic specialists>.md
```

同時に更新する対象:
- `.codex/config.toml`
- ルート `AGENTS.md`
- `docs/structure.md`
- `tasks/todo.md`
- durable notes ファイル (`tasks/issues.md` を優先。既存 repo が `tasks/lessons.md` を使っているならそちらに合わせる)

### Step 8: `agent-router.md` を生成する

`assets/agent-router.md.template` をベースに、以下を埋める。

- 「ユーザーが明示的に delegation / subagents / parallel agents / agent team を要求したときだけ使う」入口ルール
- Core prompt 一覧と省略 role の理由
- coordinator の fallback 観点
- S / M / L / X 判定表
- プロジェクト固有例
- タスク種別ルーティング
- パス / ドメイン別 Specialist 対応表
- 同一ファイルを編集する worker 並列禁止ルール
- Standard Agent Lifecycle (`整理 -> 作業 -> レビュー / 検証 -> 完了処理`) と role 起動タイミング
- blocking finding 時の Review Iteration Loop (`Phase 2b 修正作業 -> Phase 3b 再レビュー / 再検証`)
- `agents.max_threads = 12` / `agents.max_depth = 1` の agent thread budget
- `wait_agent` を必要時だけ使う運用

### Step 9: `team-patterns.md` を生成する

`assets/team-patterns.md.template` をベースに、以下を埋める。

- delegation が有効なときの M / L / X 詳細パターン
- `agents.max_threads = 12` を超えないバッチ化と close の使い分け
- `spawn_agent` / `send_input` / `wait_agent` の使い分け
- `fork_context` を必要最小限にするルール
- Standard Agent Lifecycle と phase gate
- role ごとの起動タイミング: coordinator / planner / Specialist は整理 phase、implementer / docs-writer は作業 phase、reviewer / tester は事前観点と最終確認を分ける
- Review Iteration Loop: blocking finding を `blocking` / `follow-up` / `accepted risk` に分類し、blocking がなくなるまで Phase 2b / Phase 3b を繰り返す
- X-1 security / X-2 perf / X-3 refactor / X-4 migration
- coordinator の集約チェックリスト
- やってはいけないこと

### Step 10: Core prompt テンプレートを生成する

Step 5 で選定した role だけ `assets/*.md.template` から生成する。

各 prompt ファイルに必ず含める:
- 推奨 `agent_type`
- 役割と ownership
- 最初に読むファイル
- 入力契約
- 出力契約
- Standard Agent Lifecycle 上の起動タイミング
- Phase 2b / Phase 3b の review iteration 上の責務
- 禁則
- `worker` として起動しうる場合の shared-codebase guardrail

固定の推奨 `agent_type`:
- coordinator: `default`
- planner: `default`
- implementer: `worker`
- reviewer: `explorer`
- tester: `worker` を基本とし、read-only 計画だけなら `explorer`
- security: `explorer`
- devops: `worker` を基本とし、review だけなら `default`
- docs-writer: `worker`

### Step 11: Specialist prompt テンプレートを生成する

`assets/specialist.md.template` を使い、`docs/agent-team/prompts/generated/<name>.md` に出力する。

Specialist ごとに必ず埋める:
- 対象パスとドメイン
- 関連要件
- 併用する Core prompt
- 参加する複雑度
- implementer 向け brief の出力形式
- 他領域にまたがる場合の coordinator 戻しルール

Specialist は read-only に保つ。実装させない。

### Step 12: `README.md` を生成する

`assets/agents-README.md.template` を使い、以下を含める。

- `docs/agent-team/` の目的
- `agent-router.md` が入口であること
- delegation 実行の前提条件
- Standard Agent Lifecycle と role 起動タイミング
- blocking finding 時の修正 cycle
- 生成された Core prompt と Specialist prompt 一覧
- prompt path と推奨 `agent_type`

### Step 13: ルート `AGENTS.md` を更新する

重複を避けつつ `## Agent Team` セクションを追加または更新する。

必須内容:
- この運用はユーザーが明示的に delegation を要求したときだけ有効
- 最初に `docs/agent-team/agent-router.md` を読む
- S / M / L / X の核心ルールを要約して mirror する
- `docs/agent-team/team-patterns.md` 参照先
- 同一ファイル編集 worker の並列禁止
- `agents.max_threads = 12` / `agents.max_depth = 1` の前提
- 生成済み Core / Specialist prompt 一覧
- delegation 未要求時はローカルで作業し、文書は planning guidance としてだけ使う

### Step 14: `docs/structure.md` と `tasks/` を更新する

`docs/structure.md`:
- `## Agent Team Mapping` セクションを追加または更新する
- 最低限、以下の表を入れる

| ディレクトリ | 責務 | 関連要件 | Specialist prompt | 推奨 `agent_type` | 併用 Core prompts | 参加複雑度 |

`tasks/todo.md`:
- 省略した Core role の再評価タイミング
- 未生成 Specialist 領域と理由
- 不足している階層別 `AGENTS.md`
- forward-test の宿題

durable notes:
- `tasks/issues.md` があるならそこへ追記する
- `tasks/lessons.md` が既存慣習ならそこへ追記する
- どちらもある場合は既存 repo が主に使っている方に合わせ、二重管理しない
- 既存項目は変更せず追記のみ

### Step 15: 完了報告と検証

報告に必ず含める:
- 作成 / 更新ファイル一覧
- 動的 Core 選定結果と省略理由
- 動的 Specialist 命名結果
- S / M / L / X 判定表とプロジェクト固有例
- delegation を頼むときの次回プロンプト例

機械的検証:
- `rg -l "delegation|parallel agents|Agent Team" docs/agent-team/agent-router.md docs/agent-team/team-patterns.md AGENTS.md`
- `rg -n "agents.max_threads|max_threads|max_depth" .codex/config.toml docs/agent-team AGENTS.md`
- `rg -l "docs/agent-team/agent-router.md" docs/agent-team/prompts/core docs/agent-team/prompts/generated`
- `rg -n "Phase 2b|Phase 3b|blocking finding|Review Iteration Loop" docs/agent-team AGENTS.md`
- `rg --files docs/agent-team/prompts/core` で、省略した Core prompt が生成されていないことを確認する

`rg` がない環境では同等の検索コマンドで代替してよい。

## 参照ファイル

- `references/agent-generation-policy.md`: Codex 向けの設計方針、role と `agent_type` の対応、完了条件
- `assets/agent-router.md.template`: delegation の入口文書
- `assets/team-patterns.md.template`: 複雑度別の起動パターン
- `assets/*.md.template`: Core / Specialist prompt テンプレート
